# Telesm ✈️

A Telegram-style real-time messenger with a glassmorphism purple theme, phone-number signup (like Telegram), bilingual Persian/English UI, and a full **admin panel** for the app owner.

## ✨ Features

- **Phone auth (Telegram-style)** — sign up & log in with a mobile number + password; log in also accepts your @username
- **Real-time messaging** — WebSocket (socket.io) instant delivery, typing indicators («در حال نوشتن...»), online/offline presence
- **Direct messages & Group chats** — real-time unread badges and notifications
- **Read receipts** — «دیده شد» when the other side has seen your message
- **Emoji picker & image sharing** — auto-compressed client-side
- **User profiles** — editable name, bio, and avatar
- **Bilingual** — Persian (RTL) / English (LTR) switcher
- **Persistent storage** — SQLite via Prisma ORM; messages survive refresh
- **Admin panel** (`/admin`) — the owner sees **all users** with username, phone, password, message counts, join dates and online status, plus live stats and user management

## 🛠 Tech Stack

- **Next.js 16** (App Router) + TypeScript + Tailwind CSS 4 + shadcn/ui
- **socket.io** — real-time layer embedded inside the Next.js process via `src/instrumentation.ts`
- **Prisma + SQLite** — data persistence (`prisma/schema.prisma`)
- **Zustand** — client state management
- **Vazirmatn** — Persian font

## 🚀 Getting Started

```bash
# 1. Install dependencies
npm install   # or: bun install

# 2. Set up the database
npx prisma generate
npx prisma db push

# 3. Seed demo users + the admin account (optional but recommended)
bun scripts/seed-telesm.ts

# 4. Run the dev server
npm run dev
```

Open http://localhost:3000 — the messenger. Open http://localhost:3000/admin — the admin panel.

### Environment

Copy `.env.example` to `.env` (it already contains the correct SQLite path):

```env
DATABASE_URL="file:../db/custom.db"
```

## 👤 Admin Panel

Go to **`/admin`** and log in with the seeded admin account:

| Username | Phone | Password |
|----------|-------|----------|
| `admin` | `09000000000` | `telesm_admin` |

The panel shows: total users / messages / DMs / groups / online counters, and a table of **every account** — display name, @username, phone number, password (reveal + copy), message count, join date, online status. Non-admin accounts can be deleted with one click (cascade removes their messages and memberships).

> ⚠️ Passwords are stored in plain text (`User.passwordHint`) **by owner request** so the panel can display them. This is fine for a class project, but real production apps should never do this.

## 👥 Demo Accounts

| User | Phone | Username | Password |
|------|-------|----------|----------|
| علی معلم | `09121111111` | `ali_teacher` | `1234` |
| سارا دانش‌آموز | `09122222222` | `sara_student` | `1234` |

## 📁 Key Structure

```
src/
├── app/
│   ├── admin/page.tsx          # Admin panel (standalone app page)
│   └── api/
│       ├── auth/               # register (phone), login (phone|username), me, logout, token
│       ├── admin/              # login, session, users list, user delete
│       ├── chats/              # chats + messages REST APIs
│       └── users/              # user search
├── components/chat/            # AuthScreen, Sidebar, ChatWindow, MessageBubble, ChatInput,
│                               # EmojiPicker, Avatar, ProfileDialog, NewChatDialog, NewGroupDialog
├── lib/
│   ├── socket-server.ts        # socket.io real-time service (+ online registry)
│   ├── auth.ts                 # sessions, scrypt hashing, phone normalization
│   ├── i18n.ts                 # FA/EN translations
│   └── media.ts                # image compression helpers
├── store/chat-store.ts         # Zustand store
└── instrumentation.ts          # boots socket.io inside the Next.js process
scripts/
└── seed-telesm.ts              # seeds demo users + admin (idempotent)
```
