'use client'

import { create } from 'zustand'
import type { ChatMessage, ChatSummary, PublicUser } from '@/lib/types'

type ChatState = {
  me: PublicUser | null
  setMe: (u: PublicUser | null) => void

  chats: ChatSummary[]
  setChats: (chats: ChatSummary[]) => void
  upsertChat: (chat: ChatSummary) => void

  activeChatId: string | null
  setActiveChatId: (id: string | null) => void

  messages: Record<string, ChatMessage[]>
  setMessages: (chatId: string, msgs: ChatMessage[]) => void
  addMessage: (msg: ChatMessage) => void
  replaceTemp: (chatId: string, tempId: string, msg: ChatMessage) => void

  onlineIds: Set<string>
  setOnlineIds: (ids: string[]) => void
  setOnline: (userId: string, online: boolean) => void

  typing: Record<string, Record<string, { displayName: string; at: number }>>
  setTyping: (chatId: string, userId: string, displayName: string, isTyping: boolean) => void

  users: PublicUser[]
  setUsers: (u: PublicUser[]) => void

  lastRead: Record<string, Record<string, string>>
  setLastRead: (chatId: string, userId: string, iso: string) => void
}

export const useChatStore = create<ChatState>()((set) => ({
  me: null,
  setMe: (me) => set({ me }),

  chats: [],
  setChats: (chats) => set({ chats }),
  upsertChat: (chat) =>
    set((s) => {
      const idx = s.chats.findIndex((c) => c.id === chat.id)
      const chats = [...s.chats]
      if (idx >= 0) chats[idx] = { ...chats[idx], ...chat }
      else chats.unshift(chat)
      return { chats }
    }),

  activeChatId: null,
  setActiveChatId: (activeChatId) => set({ activeChatId }),

  messages: {},
  setMessages: (chatId, msgs) =>
    set((s) => ({ messages: { ...s.messages, [chatId]: msgs } })),
  addMessage: (msg) =>
    set((s) => {
      const list = s.messages[msg.chatId] ?? []
      if (list.some((m) => m.id === msg.id)) return s
      return { messages: { ...s.messages, [msg.chatId]: [...list, msg] } }
    }),
  replaceTemp: (chatId, tempId, msg) =>
    set((s) => {
      const list = s.messages[chatId] ?? []
      const filtered = list.filter((m) => m.tempId !== tempId && m.id !== msg.id)
      return { messages: { ...s.messages, [chatId]: [...filtered, msg] } }
    }),

  onlineIds: new Set<string>(),
  setOnlineIds: (ids) => set({ onlineIds: new Set(ids) }),
  setOnline: (userId, online) =>
    set((s) => {
      const next = new Set(s.onlineIds)
      if (online) next.add(userId)
      else next.delete(userId)
      return { onlineIds: next }
    }),

  typing: {},
  setTyping: (chatId, userId, displayName, isTyping) =>
    set((s) => {
      const chatTyping = { ...(s.typing[chatId] ?? {}) }
      if (isTyping) chatTyping[userId] = { displayName, at: Date.now() }
      else delete chatTyping[userId]
      return { typing: { ...s.typing, [chatId]: chatTyping } }
    }),

  users: [],
  setUsers: (users) => set({ users }),

  lastRead: {},
  setLastRead: (chatId, userId, iso) =>
    set((s) => ({
      lastRead: {
        ...s.lastRead,
        [chatId]: { ...(s.lastRead[chatId] ?? {}), [userId]: iso },
      },
    })),
}))

export function getPeer(chat: ChatSummary, meId: string): PublicUser | null {
  return chat.members.find((m) => m.id !== meId) ?? null
}

export function chatTitle(chat: ChatSummary, meId: string, youLabel: string): string {
  if (chat.type === 'group') return chat.name || 'Group'
  const peer = getPeer(chat, meId)
  return peer?.displayName || youLabel
}
