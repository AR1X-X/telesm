export async function register() {
  // Start the embedded realtime (socket.io) server inside the Next.js process.
  // Only on the Node.js runtime.
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    const { ensureSocketServer } = await import('@/lib/socket-server')
    ensureSocketServer()
  }
}
