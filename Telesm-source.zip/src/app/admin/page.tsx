'use client'

import { useCallback, useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useLang, t } from '@/lib/i18n'
import type { AdminUserRow } from '@/app/api/admin/users/route'
import {
  Send, Globe, Loader2, LogOut, Search, Copy, Check, Trash2, RefreshCw,
  Users, MessageSquare, MessagesSquare, Wifi, ShieldCheck, Eye, EyeOff, ArrowLeft,
} from 'lucide-react'

type Stats = {
  totalUsers: number
  totalMessages: number
  totalChats: number
  totalGroups: number
  onlineNow: number
}

const L = {
  fa: {
    panel: 'پنل مدیریت تلسِم',
    login: 'ورود مدیر',
    loginHint: 'ورود با شماره یا نام کاربری مدیر',
    stats: 'آمار کلی',
    usersTable: 'همه کاربرها',
    searchAll: 'جستجوی اسم، یوزرنیم یا شماره...',
    name: 'نام',
    username: 'یوزرنیم',
    phone: 'شماره',
    password: 'گذرواژه',
    msgs: 'پیام‌ها',
    joined: 'عضویت',
    status: 'وضعیت',
    actions: 'عملیات',
    online: 'آنلاین',
    offline: 'آفلاین',
    admin: 'مدیر',
    delete: 'حذف',
    deleteConfirm: 'این کاربر و همه پیام‌هایش حذف شود؟',
    deleted: 'کاربر حذف شد',
    loadFailed: 'بارگذاری ناموفق بود',
    wrongCredentials: 'شماره/یوزرنیم یا گذرواژه اشتباهه',
    notAdmin: 'این اکانت دسترسی مدیر نداره',
    empty: 'کاربری نیست',
    backToChat: 'بازگشت به چت',
    copied: 'کپی شد',
  },
  en: {
    panel: 'Telesm Admin Panel',
    login: 'Admin login',
    loginHint: 'Sign in with the admin phone or username',
    stats: 'Overview',
    usersTable: 'All users',
    searchAll: 'Search name, username or phone...',
    name: 'Name',
    username: 'Username',
    phone: 'Phone',
    password: 'Password',
    msgs: 'Messages',
    joined: 'Joined',
    status: 'Status',
    actions: 'Actions',
    online: 'online',
    offline: 'offline',
    admin: 'admin',
    delete: 'Delete',
    deleteConfirm: 'Delete this user and all their messages?',
    deleted: 'User deleted',
    loadFailed: 'Failed to load',
    wrongCredentials: 'Wrong phone/username or password',
    notAdmin: 'This account has no admin access',
    empty: 'No users yet',
    backToChat: 'Back to chat',
    copied: 'Copied',
  },
} as const

export default function AdminPage() {
  const { lang, toggle } = useLang()
  const s = L[lang]
  const [authed, setAuthed] = useState<boolean | null>(null)
  const [identifier, setIdentifier] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [users, setUsers] = useState<AdminUserRow[]>([])
  const [stats, setStats] = useState<Stats | null>(null)
  const [query, setQuery] = useState('')
  const [reveal, setReveal] = useState<Record<string, boolean>>({})
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const [deleting, setDeleting] = useState<string | null>(null)

  const loadData = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/users')
      if (res.status === 403) {
        setAuthed(false)
        return
      }
      const data = await res.json()
      setUsers(data.users || [])
      setStats(data.stats || null)
      setAuthed(true)
    } catch {
      setError(s.loadFailed)
    }
  }, [s.loadFailed])

  useEffect(() => {
    fetch('/api/admin/session')
      .then((r) => (r.ok ? setAuthed(true) : setAuthed(false)))
      .catch(() => setAuthed(false))
  }, [])

  useEffect(() => {
    if (authed) loadData()
  }, [authed, loadData])

  const login = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier, password }),
      })
      const data = await res.json()
      if (!res.ok) {
        setError(s[data.error as 'wrongCredentials' | 'notAdmin'] || s.wrongCredentials)
        return
      }
      setAuthed(true)
    } catch {
      setError(s.loadFailed)
    } finally {
      setLoading(false)
    }
  }

  const logout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' }).catch(() => {})
    setAuthed(false)
    setUsers([])
    setStats(null)
  }

  const removeUser = async (u: AdminUserRow) => {
    if (!confirm(s.deleteConfirm)) return
    setDeleting(u.id)
    try {
      const res = await fetch(`/api/admin/users/${u.id}`, { method: 'DELETE' })
      if (res.ok) {
        setUsers((prev) => prev.filter((x) => x.id !== u.id))
        loadData()
      }
    } finally {
      setDeleting(null)
    }
  }

  const copyPassword = async (u: AdminUserRow) => {
    try {
      await navigator.clipboard.writeText(u.passwordHint)
      setCopiedId(u.id)
      setTimeout(() => setCopiedId(null), 1500)
    } catch {
      /* clipboard unavailable */
    }
  }

  const q = query.trim().toLowerCase()
  const filtered = q
    ? users.filter(
        (u) =>
          u.displayName.toLowerCase().includes(q) ||
          u.username.toLowerCase().includes(q) ||
          (u.phone || '').includes(q)
      )
    : users

  if (authed === null) {
    return (
      <div className="flex min-h-dvh items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-white/50" />
      </div>
    )
  }

  if (!authed) {
    return (
      <div className="flex min-h-dvh items-center justify-center p-4">
        <button
          type="button"
          onClick={toggle}
          className="glass absolute top-5 end-5 flex items-center gap-2 rounded-full px-4 py-2 text-sm text-white/80 transition hover:bg-white/15"
        >
          <Globe className="h-4 w-4" />
          {lang === 'fa' ? 'English' : 'فارسی'}
        </button>

        <div className="glass-strong w-full max-w-sm rounded-3xl p-7 shadow-2xl">
          <div className="mb-6 flex flex-col items-center gap-3 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-sky-400 via-violet-500 to-fuchsia-500 shadow-lg shadow-fuchsia-500/30">
              <ShieldCheck className="h-7 w-7 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">{s.panel}</h1>
              <p className="mt-1 text-xs text-white/50">{s.loginHint}</p>
            </div>
          </div>

          <form onSubmit={login} className="space-y-3">
            <Input
              dir="ltr"
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              placeholder="admin / 09000000000"
              className="glass-input h-11 text-start"
              required
            />
            <Input
              dir="ltr"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="glass-input h-11 text-start"
              required
            />
            {error && (
              <div className="rounded-xl border border-rose-400/30 bg-rose-500/15 px-3 py-2 text-xs text-rose-200">
                {error}
              </div>
            )}
            <Button
              type="submit"
              disabled={loading}
              className="h-11 w-full bg-gradient-to-r from-sky-400 via-violet-500 to-fuchsia-500 font-semibold text-white shadow-lg shadow-fuchsia-500/25 hover:opacity-90"
            >
              {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : s.login}
            </Button>
          </form>

          <a
            href="/"
            className="mt-4 flex items-center justify-center gap-1 text-xs text-white/40 transition hover:text-white/70"
          >
            <ArrowLeft className="h-3 w-3" />
            {s.backToChat}
          </a>
        </div>
      </div>
    )
  }

  const statCards = stats
    ? [
        { icon: Users, label: lang === 'fa' ? 'کاربرها' : 'Users', value: stats.totalUsers },
        { icon: MessageSquare, label: lang === 'fa' ? 'پیام‌ها' : 'Messages', value: stats.totalMessages },
        { icon: MessagesSquare, label: lang === 'fa' ? 'چت خصوصی' : 'DMs', value: stats.totalChats },
        { icon: MessagesSquare, label: lang === 'fa' ? 'گروه‌ها' : 'Groups', value: stats.totalGroups },
        { icon: Wifi, label: lang === 'fa' ? 'آنلاین' : 'Online', value: stats.onlineNow },
      ]
    : []

  return (
    <div className="mx-auto min-h-dvh w-full max-w-6xl p-4 md:p-8">
      {/* header */}
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-sky-400 via-violet-500 to-fuchsia-500 shadow-lg shadow-fuchsia-500/30">
            <Send className="h-5 w-5 -translate-x-px translate-y-px text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">{s.panel}</h1>
            <p className="text-xs text-white/50">{t(lang, 'tagline')}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={toggle}
            className="glass flex items-center gap-2 rounded-full px-3 py-2 text-xs text-white/80 transition hover:bg-white/15"
          >
            <Globe className="h-4 w-4" />
            {lang === 'fa' ? 'EN' : 'فا'}
          </button>
          <button
            type="button"
            onClick={loadData}
            className="glass flex items-center gap-2 rounded-full px-3 py-2 text-xs text-white/80 transition hover:bg-white/15"
          >
            <RefreshCw className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={logout}
            className="glass flex items-center gap-2 rounded-full px-3 py-2 text-xs text-rose-200 transition hover:bg-rose-500/20"
          >
            <LogOut className="h-4 w-4" />
            {t(lang, 'logout')}
          </button>
        </div>
      </div>

      {/* stats */}
      <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {statCards.map((c) => (
          <div key={c.label} className="glass rounded-2xl p-4">
            <c.icon className="mb-2 h-5 w-5 text-fuchsia-300" />
            <div className="text-2xl font-bold text-white">{c.value.toLocaleString(lang === 'fa' ? 'fa-IR' : 'en-US')}</div>
            <div className="text-xs text-white/50">{c.label}</div>
          </div>
        ))}
      </div>

      {/* users table */}
      <div className="glass-strong overflow-hidden rounded-3xl">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 p-4">
          <h2 className="font-semibold text-white">{s.usersTable}</h2>
          <div className="relative w-full sm:w-72">
            <Search className="absolute top-1/2 start-3 h-4 w-4 -translate-y-1/2 text-white/40" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={s.searchAll}
              className="glass-input h-9 ps-9 text-sm"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[860px] text-sm">
            <thead>
              <tr className="border-b border-white/10 text-start text-xs text-white/50">
                <th className="p-3 text-start font-medium">{s.name}</th>
                <th className="p-3 text-start font-medium">{s.username}</th>
                <th className="p-3 text-start font-medium">{s.phone}</th>
                <th className="p-3 text-start font-medium">{s.password}</th>
                <th className="p-3 text-start font-medium">{s.msgs}</th>
                <th className="p-3 text-start font-medium">{s.joined}</th>
                <th className="p-3 text-start font-medium">{s.status}</th>
                <th className="p-3 text-start font-medium">{s.actions}</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-white/40">
                    {s.empty}
                  </td>
                </tr>
              )}
              {filtered.map((u) => (
                <tr key={u.id} className="border-b border-white/5 transition hover:bg-white/5">
                  <td className="p-3">
                    <div className="flex items-center gap-2">
                      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-500 text-xs font-bold text-white">
                        {u.displayName.trim().charAt(0) || '?'}
                      </div>
                      <span className="font-medium text-white">{u.displayName}</span>
                      {u.role === 'ADMIN' && (
                        <span className="rounded-full bg-amber-400/20 px-2 py-0.5 text-[10px] text-amber-200">
                          {s.admin}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="p-3" dir="ltr">
                    <span className="text-white/80">@{u.username}</span>
                  </td>
                  <td className="p-3" dir="ltr">
                    <span className="font-mono text-white/80">{u.phone || '—'}</span>
                  </td>
                  <td className="p-3">
                    <div className="flex items-center gap-1.5" dir="ltr">
                      <span className="font-mono text-white/80">
                        {reveal[u.id] ? u.passwordHint : '••••••••'}
                      </span>
                      <button
                        type="button"
                        onClick={() => setReveal((p) => ({ ...p, [u.id]: !p[u.id] }))}
                        className="text-white/40 transition hover:text-white"
                        aria-label="toggle password"
                      >
                        {reveal[u.id] ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                      </button>
                      <button
                        type="button"
                        onClick={() => copyPassword(u)}
                        className="text-white/40 transition hover:text-white"
                        aria-label="copy password"
                      >
                        {copiedId === u.id ? (
                          <Check className="h-3.5 w-3.5 text-emerald-300" />
                        ) : (
                          <Copy className="h-3.5 w-3.5" />
                        )}
                      </button>
                    </div>
                  </td>
                  <td className="p-3 text-white/80">{u.messageCount.toLocaleString(lang === 'fa' ? 'fa-IR' : 'en-US')}</td>
                  <td className="p-3 text-white/60">
                    {new Date(u.createdAt).toLocaleDateString(lang === 'fa' ? 'fa-IR' : 'en-US', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                    })}
                  </td>
                  <td className="p-3">
                    <span
                      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs ${
                        u.online
                          ? 'bg-emerald-400/15 text-emerald-200'
                          : 'bg-white/10 text-white/50'
                      }`}
                    >
                      <span
                        className={`h-1.5 w-1.5 rounded-full ${
                          u.online ? 'bg-emerald-300' : 'bg-white/30'
                        }`}
                      />
                      {u.online ? s.online : s.offline}
                    </span>
                  </td>
                  <td className="p-3">
                    {u.role !== 'ADMIN' && (
                      <button
                        type="button"
                        onClick={() => removeUser(u)}
                        disabled={deleting === u.id}
                        className="flex items-center gap-1 rounded-lg bg-rose-500/15 px-2.5 py-1.5 text-xs text-rose-200 transition hover:bg-rose-500/30 disabled:opacity-50"
                      >
                        {deleting === u.id ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        ) : (
                          <Trash2 className="h-3.5 w-3.5" />
                        )}
                        {s.delete}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
