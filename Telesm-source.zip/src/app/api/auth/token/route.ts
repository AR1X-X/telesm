import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { db } from '@/lib/db'
import { SESSION_COOKIE } from '@/lib/auth'
import { ensureSocketServer } from '@/lib/socket-server'

/** Returns the raw session token for the current cookie (used by the socket client). */
export async function GET() {
  try {
    // make sure the embedded realtime server is running (lazy start)
    ensureSocketServer()

    const cookieStore = await cookies()
    const token = cookieStore.get(SESSION_COOKIE)?.value
    if (!token) return NextResponse.json({ token: null }, { status: 401 })
    const session = await db.session.findUnique({ where: { token } })
    if (!session) return NextResponse.json({ token: null }, { status: 401 })
    return NextResponse.json({ token })
  } catch (e) {
    console.error('token error', e)
    return NextResponse.json({ token: null }, { status: 500 })
  }
}
