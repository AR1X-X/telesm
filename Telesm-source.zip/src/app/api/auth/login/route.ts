import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import {
  SESSION_COOKIE,
  cookieOptions,
  createSession,
  normalizePhone,
  publicUser,
  verifyPassword,
} from '@/lib/auth'

type DbUser = Awaited<ReturnType<typeof db.user.findFirst>>

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const identifier = String(body.identifier || body.username || '').trim()
    const password = String(body.password || '')

    // accept a phone number OR a username (Telegram-style)
    let user: DbUser = null
    const phone = normalizePhone(identifier)
    if (phone) {
      user = await db.user.findUnique({ where: { phone } })
    }
    if (!user && /^[a-zA-Z0-9_]{3,20}$/.test(identifier.toLowerCase())) {
      user = await db.user.findUnique({ where: { username: identifier.toLowerCase() } })
    }

    if (!user || !verifyPassword(password, user.password)) {
      return NextResponse.json({ error: 'wrongCredentials' }, { status: 401 })
    }

    const token = await createSession(user.id)
    const res = NextResponse.json({ user: publicUser(user) })
    res.cookies.set(SESSION_COOKIE, token, cookieOptions())
    return res
  } catch (e) {
    console.error('login error', e)
    return NextResponse.json({ error: 'server' }, { status: 500 })
  }
}
