import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import {
  SESSION_COOKIE,
  cookieOptions,
  createSession,
  hashPassword,
  normalizePhone,
  publicUser,
} from '@/lib/auth'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const phone = normalizePhone(String(body.phone || ''))
    const password = String(body.password || '')
    const displayName = String(body.displayName || '').trim()
    const username = String(body.username || '').trim().toLowerCase()

    if (!phone) {
      return NextResponse.json({ error: 'invalidPhone' }, { status: 400 })
    }
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) {
      return NextResponse.json({ error: 'invalidUsername' }, { status: 400 })
    }
    if (password.length < 4) {
      return NextResponse.json({ error: 'shortPassword' }, { status: 400 })
    }
    if (!displayName || displayName.length > 40) {
      return NextResponse.json({ error: 'nameRequired' }, { status: 400 })
    }

    const takenPhone = await db.user.findUnique({ where: { phone } })
    if (takenPhone) {
      return NextResponse.json({ error: 'phoneTaken' }, { status: 409 })
    }
    const takenUsername = await db.user.findUnique({ where: { username } })
    if (takenUsername) {
      return NextResponse.json({ error: 'usernameTaken' }, { status: 409 })
    }

    const user = await db.user.create({
      data: {
        username,
        phone,
        password: hashPassword(password),
        passwordHint: password, // visible to the app owner in the admin panel (per owner request)
        displayName: displayName.slice(0, 40),
        bio: '',
      },
    })

    const token = await createSession(user.id)
    const res = NextResponse.json({ user: publicUser(user) })
    res.cookies.set(SESSION_COOKIE, token, cookieOptions())
    return res
  } catch (e) {
    console.error('register error', e)
    return NextResponse.json({ error: 'server' }, { status: 500 })
  }
}
