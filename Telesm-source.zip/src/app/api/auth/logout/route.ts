import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { SESSION_COOKIE } from '@/lib/auth'
import type { NextRequest as _NR } from 'next/server'

export async function POST(_req: NextRequest) {
  try {
    const cookieStore = await _req.cookies
    const token = cookieStore.get(SESSION_COOKIE)?.value
    if (token) {
      await db.session.deleteMany({ where: { token } })
    }
  } catch (e) {
    console.error('logout error', e)
  }
  const res = NextResponse.json({ ok: true })
  res.cookies.set(SESSION_COOKIE, '', { httpOnly: true, path: '/', maxAge: 0 })
  return res
}
