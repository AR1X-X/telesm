import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser, publicUser } from '@/lib/auth'

export async function GET() {
  try {
    const me = await getSessionUser()
    if (!me) return NextResponse.json({ error: 'unauthorized' }, { status: 401 })

    const users = await db.user.findMany({
      where: { id: { not: me.id } },
      orderBy: { displayName: 'asc' },
      select: {
        id: true,
        username: true,
        displayName: true,
        avatar: true,
        bio: true,
      },
    })
    return NextResponse.json({ users: users.map(publicUser) })
  } catch (e) {
    console.error('users error', e)
    return NextResponse.json({ error: 'server' }, { status: 500 })
  }
}
