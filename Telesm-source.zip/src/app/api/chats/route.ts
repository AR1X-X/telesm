import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser, publicUser } from '@/lib/auth'
import type { ChatSummary } from '@/lib/types'

function buildChatSummary(
  chat: {
    id: string
    type: string
    name: string | null
    avatar: string | null
    createdAt: Date
    updatedAt: Date
    members: { user: { id: string; username: string; displayName: string; avatar: string | null; bio: string } }[]
  },
  meId: string,
  lastMessage: {
    id: string
    text: string | null
    image: string | null
    createdAt: Date
    senderId: string
    sender: { displayName: string }
  } | null,
  unreadCount: number,
  memberRead: Record<string, string> = {}
): ChatSummary {
  return {
    id: chat.id,
    type: chat.type as 'dm' | 'group',
    name: chat.name,
    avatar: chat.avatar,
    createdAt: chat.createdAt.toISOString(),
    updatedAt: chat.updatedAt.toISOString(),
    members: chat.members.map((m) => publicUser(m.user)),
    memberRead,
    lastMessage: lastMessage
      ? {
          id: lastMessage.id,
          text: lastMessage.text,
          image: lastMessage.image,
          createdAt: lastMessage.createdAt.toISOString(),
          senderId: lastMessage.senderId,
          senderName: lastMessage.sender.displayName,
        }
      : null,
    unreadCount,
  }
}

export async function GET() {
  try {
    const me = await getSessionUser()
    if (!me) return NextResponse.json({ error: 'unauthorized' }, { status: 401 })

    const memberships = await db.chatMember.findMany({
      where: { userId: me.id },
      include: {
        chat: {
          include: {
            members: { include: { user: true } },
          },
        },
      },
    })

    const summaries: ChatSummary[] = []
    for (const membership of memberships) {
      const chat = membership.chat
      const [lastMessage, unreadCount] = await Promise.all([
        db.message.findFirst({
          where: { chatId: chat.id },
          orderBy: { createdAt: 'desc' },
          include: { sender: { select: { displayName: true } } },
        }),
        db.message.count({
          where: {
            chatId: chat.id,
            senderId: { not: me.id },
            createdAt: { gt: membership.lastReadAt },
          },
        }),
      ])
      summaries.push(
        buildChatSummary(chat, me.id, lastMessage, unreadCount, {
          [membership.userId]: membership.lastReadAt.toISOString(),
        })
      )
    }

    summaries.sort((a, b) => {
      const ta = a.lastMessage?.createdAt ?? a.updatedAt
      const tb = b.lastMessage?.createdAt ?? b.updatedAt
      return tb < ta ? -1 : tb > ta ? 1 : 0
    })

    return NextResponse.json({ chats: summaries })
  } catch (e) {
    console.error('chats GET error', e)
    return NextResponse.json({ error: 'server' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const me = await getSessionUser()
    if (!me) return NextResponse.json({ error: 'unauthorized' }, { status: 401 })

    const body = await req.json()
    const type = body.type === 'group' ? 'group' : 'dm'

    if (type === 'dm') {
      const targetId = String(body.userId || '')
      if (!targetId || targetId === me.id) {
        return NextResponse.json({ error: 'badRequest' }, { status: 400 })
      }
      const target = await db.user.findUnique({ where: { id: targetId } })
      if (!target) return NextResponse.json({ error: 'notFound' }, { status: 404 })

      // find existing dm between the two
      const mine = await db.chatMember.findMany({
        where: { userId: me.id },
        select: { chatId: true },
      })
      const theirs = await db.chatMember.findMany({
        where: { userId: targetId },
        select: { chatId: true },
      })
      const mineSet = new Set(mine.map((m) => m.chatId))
      const shared = theirs.filter((m) => mineSet.has(m.chatId)).map((m) => m.chatId)

      for (const chatId of shared) {
        const chat = await db.chat.findUnique({
          where: { id: chatId },
          include: { members: { include: { user: true } } },
        })
        if (chat && chat.type === 'dm' && chat.members.length === 2) {
          return NextResponse.json({
            chat: buildChatSummary(chat, me.id, null, 0, {}),
            created: false,
          })
        }
      }

      const chat = await db.chat.create({
        data: {
          type: 'dm',
          createdBy: me.id,
          members: {
            create: [{ userId: me.id }, { userId: targetId }],
          },
        },
        include: { members: { include: { user: true } } },
      })
      return NextResponse.json({
        chat: buildChatSummary(chat, me.id, null, 0, {}),
        created: true,
      })
    }

    // group
    const name = String(body.name || '').trim()
    if (!name || name.length > 50) {
      return NextResponse.json({ error: 'groupNameRequired' }, { status: 400 })
    }
    const memberIds: string[] = Array.isArray(body.memberIds)
      ? Array.from(new Set(body.memberIds.map(String).filter((id: string) => id !== me.id)))
      : []
    if (memberIds.length === 0) {
      return NextResponse.json({ error: 'selectMemberFirst' }, { status: 400 })
    }
    const validUsers = await db.user.findMany({
      where: { id: { in: memberIds } },
      select: { id: true },
    })
    if (validUsers.length === 0) {
      return NextResponse.json({ error: 'selectMemberFirst' }, { status: 400 })
    }

    const chat = await db.chat.create({
      data: {
        type: 'group',
        name: name.slice(0, 50),
        createdBy: me.id,
        members: {
          create: [{ userId: me.id }, ...validUsers.map((u) => ({ userId: u.id }))],
        },
      },
      include: { members: { include: { user: true } } },
    })
    return NextResponse.json({
      chat: buildChatSummary(chat, me.id, null, 0, {}),
      created: true,
    })
  } catch (e) {
    console.error('chats POST error', e)
    return NextResponse.json({ error: 'server' }, { status: 500 })
  }
}
