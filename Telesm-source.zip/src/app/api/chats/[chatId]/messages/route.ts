import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser, publicUser } from '@/lib/auth'

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ chatId: string }> }
) {
  try {
    const me = await getSessionUser()
    if (!me) return NextResponse.json({ error: 'unauthorized' }, { status: 401 })

    const { chatId } = await params
    const membership = await db.chatMember.findUnique({
      where: { chatId_userId: { chatId, userId: me.id } },
    })
    if (!membership) {
      return NextResponse.json({ error: 'forbidden' }, { status: 403 })
    }

    const messages = await db.message.findMany({
      where: { chatId },
      orderBy: { createdAt: 'desc' },
      take: 80,
      include: { sender: true },
    })

    return NextResponse.json({
      messages: messages
        .reverse()
        .map((m) => ({
          id: m.id,
          chatId: m.chatId,
          senderId: m.senderId,
          text: m.text,
          image: m.image,
          createdAt: m.createdAt.toISOString(),
          sender: publicUser(m.sender),
        })),
    })
  } catch (e) {
    console.error('messages GET error', e)
    return NextResponse.json({ error: 'server' }, { status: 500 })
  }
}
