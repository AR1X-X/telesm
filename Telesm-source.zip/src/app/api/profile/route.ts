import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser, publicUser } from '@/lib/auth'

export async function PATCH(req: NextRequest) {
  try {
    const me = await getSessionUser()
    if (!me) return NextResponse.json({ error: 'unauthorized' }, { status: 401 })

    const body = await req.json()
    const data: { displayName?: string; bio?: string; avatar?: string | null } = {}

    if (typeof body.displayName === 'string') {
      const name = body.displayName.trim()
      if (!name || name.length > 40) {
        return NextResponse.json({ error: 'nameRequired' }, { status: 400 })
      }
      data.displayName = name
    }
    if (typeof body.bio === 'string') {
      data.bio = body.bio.slice(0, 160)
    }
    if (typeof body.avatar === 'string' || body.avatar === null) {
      const avatar = body.avatar as string | null
      if (avatar && avatar.length > 2_500_000) {
        return NextResponse.json({ error: 'imageTooLarge' }, { status: 413 })
      }
      data.avatar = avatar
    }

    const user = await db.user.update({ where: { id: me.id }, data })
    return NextResponse.json({ user: publicUser(user) })
  } catch (e) {
    console.error('profile error', e)
    return NextResponse.json({ error: 'server' }, { status: 500 })
  }
}
