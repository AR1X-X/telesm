import { NextResponse } from 'next/server'
import { getSessionUser } from '@/lib/auth'

/** Tells the admin panel whether the current session belongs to an ADMIN. */
export async function GET() {
  try {
    const user = await getSessionUser()
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json({ admin: false }, { status: 401 })
    }
    return NextResponse.json({ admin: true, name: user.displayName })
  } catch (e) {
    console.error('admin session error', e)
    return NextResponse.json({ admin: false }, { status: 500 })
  }
}
