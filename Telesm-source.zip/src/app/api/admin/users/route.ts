import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'
import { getOnlineUserIds } from '@/lib/socket-server'

export type AdminUserRow = {
  id: string
  username: string
  phone: string | null
  passwordHint: string
  displayName: string
  bio: string
  avatar: string | null
  role: string
  createdAt: string
  messageCount: number
  chatCount: number
  online: boolean
}

/** Full user list for the admin panel: username, phone, password, stats. */
export async function GET() {
  try {
    const me = await getSessionUser()
    if (!me || me.role !== 'ADMIN') {
      return NextResponse.json({ error: 'forbidden' }, { status: 403 })
    }

    const [users, totalMessages, totalChats, totalGroups, onlineIds] = await Promise.all([
      db.user.findMany({
        orderBy: { createdAt: 'desc' },
        include: {
          _count: { select: { messages: true, members: true } },
        },
      }),
      db.message.count(),
      db.chat.count({ where: { type: 'dm' } }),
      db.chat.count({ where: { type: 'group' } }),
      Promise.resolve(getOnlineUserIds()),
    ])

    const rows: AdminUserRow[] = users.map((u) => ({
      id: u.id,
      username: u.username,
      phone: u.phone,
      passwordHint: u.passwordHint || '—',
      displayName: u.displayName,
      bio: u.bio,
      avatar: u.avatar,
      role: u.role,
      createdAt: u.createdAt.toISOString(),
      messageCount: u._count.messages,
      chatCount: u._count.members,
      online: onlineIds.includes(u.id),
    }))

    return NextResponse.json({
      users: rows,
      stats: {
        totalUsers: users.length,
        totalMessages,
        totalChats,
        totalGroups,
        onlineNow: onlineIds.length,
      },
    })
  } catch (e) {
    console.error('admin users error', e)
    return NextResponse.json({ error: 'server' }, { status: 500 })
  }
}
