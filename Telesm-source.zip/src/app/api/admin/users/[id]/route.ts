import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'

/** Remove a user (and all their chats membership / messages via cascade). */
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const me = await getSessionUser()
    if (!me || me.role !== 'ADMIN') {
      return NextResponse.json({ error: 'forbidden' }, { status: 403 })
    }

    const { id } = await params
    const target = await db.user.findUnique({ where: { id } })
    if (!target) {
      return NextResponse.json({ error: 'notFound' }, { status: 404 })
    }
    if (target.role === 'ADMIN') {
      return NextResponse.json({ error: 'cannotDeleteAdmin' }, { status: 400 })
    }

    await db.user.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    console.error('admin delete user error', e)
    return NextResponse.json({ error: 'server' }, { status: 500 })
  }
}
