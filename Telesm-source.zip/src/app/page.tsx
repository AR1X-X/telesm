'use client'

import { useEffect, useState } from 'react'
import { AuthScreen } from '@/components/chat/AuthScreen'
import { ChatApp } from '@/components/chat/ChatApp'
import { useLang } from '@/lib/i18n'
import type { PublicUser } from '@/lib/types'
import { Loader2, MessageCircle } from 'lucide-react'

export default function Home() {
  const { lang } = useLang()
  const [me, setMe] = useState<PublicUser | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    document.documentElement.lang = lang
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr'
  }, [lang])

  useEffect(() => {
    fetch('/api/auth/me')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => setMe(data?.user ?? null))
      .catch(() => setMe(null))
      .finally(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <div className="flex min-h-dvh flex-col items-center justify-center gap-4">
        <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-gradient-to-br from-violet-500 to-fuchsia-500 shadow-xl shadow-fuchsia-500/30">
          <MessageCircle className="h-8 w-8 text-white" />
        </div>
        <Loader2 className="h-5 w-5 animate-spin text-white/60" />
      </div>
    )
  }

  return (
    <main className="min-h-dvh">
      {me ? (
        <ChatApp initialMe={me} onLogout={() => setMe(null)} />
      ) : (
        <AuthScreen onAuthed={(user) => setMe(user)} />
      )}
    </main>
  )
}
