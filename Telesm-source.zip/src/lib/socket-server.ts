import { createServer } from 'http'
import { Server } from 'socket.io'

// Socket.io server embedded in the Next.js runtime process.
// The sandbox keeps the Next.js process alive (managed by the platform),
// so the realtime service survives as long as the app does.

type PublicUser = {
  id: string
  username: string
  displayName: string
  avatar: string | null
  bio: string
}

const g = globalThis as any

// live registry of online user ids (used by the admin panel stats)
if (!g.__telesmOnlineUsers) g.__telesmOnlineUsers = new Set<string>()

export function getOnlineUserIds(): string[] {
  return Array.from((g.__telesmOnlineUsers as Set<string>) ?? [])
}

export function ensureSocketServer(): void {
  if (g.__glasschatSocketServer) return
  g.__glasschatSocketServer = 'starting'

  // lazy import to avoid bundling issues
  import('@prisma/client').then(({ PrismaClient }) => {
    const prisma = new PrismaClient({
      datasourceUrl: 'file:/home/z/my-project/db/custom.db',
      log: ['error', 'warn'],
    })

    const httpServer = createServer()
    const io = new Server(httpServer, {
      // DO NOT change the path, it is used by Caddy to forward the request
      path: '/',
      cors: { origin: '*', methods: ['GET', 'POST'] },
      pingTimeout: 60000,
      pingInterval: 25000,
      maxHttpBufferSize: 8e6,
    })

    const userSockets = new Map<string, Set<string>>()

    const markOnline = (userId: string, socketId: string) => {
      if (!userSockets.has(userId)) userSockets.set(userId, new Set())
      userSockets.get(userId)!.add(socketId)
      ;(g.__telesmOnlineUsers as Set<string>).add(userId)
    }

    const markOffline = (userId: string, socketId: string) => {
      const sockets = userSockets.get(userId)
      if (sockets) {
        sockets.delete(socketId)
        if (sockets.size === 0) {
          userSockets.delete(userId)
          ;(g.__telesmOnlineUsers as Set<string>).delete(userId)
        }
      }
    }

    const toPublicUser = (u: PublicUser): PublicUser => ({ ...u })

    async function joinUserRooms(userId: string, socketId: string) {
      const memberships = await prisma.chatMember.findMany({
        where: { userId },
        select: { chatId: true },
      })
      const socket = io.sockets.sockets.get(socketId)
      if (!socket) return
      socket.join(`user:${userId}`)
      for (const m of memberships) socket.join(`chat:${m.chatId}`)
    }

    async function ensureRoomMembers(chatId: string) {
      const memberships = await prisma.chatMember.findMany({
        where: { chatId },
        select: { userId: true },
      })
      for (const m of memberships) {
        const sockets = userSockets.get(m.userId)
        if (!sockets) continue
        for (const sid of sockets) {
          const s = io.sockets.sockets.get(sid)
          if (s) s.join(`chat:${chatId}`)
        }
      }
    }

    io.on('connection', async (socket) => {
      const token = (socket.handshake.auth?.token as string) || ''
      const session = token
        ? await prisma.session.findUnique({
            where: { token },
            include: { user: true },
          })
        : null
      if (!session) {
        socket.emit('auth-error', { message: 'unauthorized' })
        socket.disconnect(true)
        return
      }

      const me = session.user
      const myId = me.id

      markOnline(myId, socket.id)

      await joinUserRooms(myId, socket.id)

      socket.emit('presence-snapshot', {
        onlineUserIds: Array.from(userSockets.keys()),
      })
      io.emit('presence', { userId: myId, online: true })

      socket.on(
        'send-message',
        async (
          data: { chatId: string; tempId?: string; text?: string; image?: string },
          ack?: (res: { ok: boolean; error?: string }) => void
        ) => {
          try {
            const { chatId, tempId, text, image } = data || {}
            if (!chatId || (!text?.trim() && !image)) {
              ack?.({ ok: false, error: 'empty' })
              return
            }
            const membership = await prisma.chatMember.findUnique({
              where: { chatId_userId: { chatId, userId: myId } },
            })
            if (!membership) {
              ack?.({ ok: false, error: 'forbidden' })
              return
            }
            const message = await prisma.message.create({
              data: {
                chatId,
                senderId: myId,
                text: text?.trim() || null,
                image: image || null,
              },
              include: { sender: true },
            })
            await prisma.chat.update({
              where: { id: chatId },
              data: { updatedAt: new Date() },
            })
            await ensureRoomMembers(chatId)
            io.to(`chat:${chatId}`).emit('new-message', {
              message: {
                id: message.id,
                chatId: message.chatId,
                senderId: message.senderId,
                text: message.text,
                image: message.image,
                createdAt: message.createdAt,
                sender: toPublicUser(message.sender as PublicUser),
              },
              tempId: tempId || null,
            })
            ack?.({ ok: true })
          } catch (e) {
            console.error('send-message error', e)
            ack?.({ ok: false, error: 'server' })
          }
        }
      )

      socket.on('typing', async (data: { chatId: string; isTyping: boolean }) => {
        if (!data?.chatId) return
        const membership = await prisma.chatMember.findUnique({
          where: { chatId_userId: { chatId: data.chatId, userId: myId } },
        })
        if (!membership) return
        socket.to(`chat:${data.chatId}`).emit('typing', {
          chatId: data.chatId,
          userId: myId,
          displayName: me.displayName,
          isTyping: !!data.isTyping,
        })
      })

      socket.on('read', async (data: { chatId: string }) => {
        if (!data?.chatId) return
        const now = new Date()
        try {
          await prisma.chatMember.update({
            where: { chatId_userId: { chatId: data.chatId, userId: myId } },
            data: { lastReadAt: now },
          })
          socket.to(`chat:${data.chatId}`).emit('chat-read', {
            chatId: data.chatId,
            userId: myId,
            lastReadAt: now,
          })
        } catch (e) {
          console.error('read error', e)
        }
      })

      socket.on(
        'user-updated',
        (data: { user: Partial<PublicUser> & { id: string } }) => {
          if (!data?.user?.id || data.user.id !== myId) return
          io.emit('user-updated', {
            user: {
              id: data.user.id,
              username: data.user.username ?? me.username,
              displayName: data.user.displayName ?? me.displayName,
              avatar: data.user.avatar ?? me.avatar,
              bio: data.user.bio ?? me.bio,
            },
          })
        }
      )

      socket.on('chat-created', async (data: { chatId: string }) => {
        try {
          if (!data?.chatId) return
          const chat = await prisma.chat.findUnique({
            where: { id: data.chatId },
            include: { members: { include: { user: true } } },
          })
          if (!chat) return
          const isMember = chat.members.some((m) => m.userId === myId)
          if (!isMember) return
          const payload = {
            id: chat.id,
            type: chat.type,
            name: chat.name,
            avatar: chat.avatar,
            createdAt: chat.createdAt,
            updatedAt: chat.updatedAt,
            members: chat.members.map((m) => toPublicUser(m.user as PublicUser)),
          }
          for (const m of chat.members) {
            const sockets = userSockets.get(m.userId)
            if (sockets) {
              for (const sid of sockets) {
                const s = io.sockets.sockets.get(sid)
                if (s) s.join(`chat:${chat.id}`)
              }
            }
            io.to(`user:${m.userId}`).emit('new-chat', { chat: payload })
          }
        } catch (e) {
          console.error('chat-created error', e)
        }
      })

      socket.on('disconnect', () => {
        markOffline(myId, socket.id)
        if (!userSockets.has(myId)) {
          io.emit('presence', { userId: myId, online: false })
        }
      })
    })

    // dual-stack bind so Caddy can reach it via both ::1 and 127.0.0.1
    httpServer.on('error', (err: NodeJS.ErrnoException) => {
      if (err.code === 'EADDRINUSE') {
        console.log('socket-server: port 3003 already in use, skipping')
      } else {
        console.error('socket-server error', err)
      }
    })
    httpServer.listen(3003, '::', () => {
      console.log('socket-server listening on [::]:3003 (in Next.js process)')
    })

    g.__glasschatSocketServer = io
  })
}
