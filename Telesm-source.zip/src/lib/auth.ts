import { cookies } from 'next/headers'
import { randomBytes, scryptSync, timingSafeEqual } from 'crypto'
import { db } from '@/lib/db'

export const SESSION_COOKIE = 'glasschat_session'

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex')
  const hash = scryptSync(password, salt, 64).toString('hex')
  return `${salt}:${hash}`
}

/** Normalize Iranian mobile numbers to the 11-digit 09xxxxxxxxx form, or null if invalid. */
export function normalizePhone(input: string): string | null {
  let s = String(input || '').replace(/[\s\-()]/g, '')
  if (s.startsWith('+98')) s = '0' + s.slice(3)
  else if (s.startsWith('98') && s.length >= 12) s = '0' + s.slice(2)
  else if (s.startsWith('0098')) s = '0' + s.slice(4)
  else if (s.startsWith('9') && s.length === 10) s = '0' + s
  if (/^09\d{9}$/.test(s)) return s
  return null
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [salt, hash] = stored.split(':')
    const hashBuf = Buffer.from(hash, 'hex')
    const testBuf = scryptSync(password, salt, 64)
    return hashBuf.length === testBuf.length && timingSafeEqual(hashBuf, testBuf)
  } catch {
    return false
  }
}

export async function createSession(userId: string): Promise<string> {
  const token = randomBytes(32).toString('hex')
  await db.session.create({ data: { token, userId } })
  return token
}

export async function getSessionUser() {
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE)?.value
  if (!token) return null
  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  })
  return session?.user ?? null
}

export function publicUser(u: {
  id: string
  username: string
  displayName: string
  avatar: string | null
  bio: string
}) {
  return {
    id: u.id,
    username: u.username,
    displayName: u.displayName,
    avatar: u.avatar,
    bio: u.bio,
  }
}

/** Same as publicUser but includes the user's own phone number (only for /api/auth/me). */
export function meUser(u: {
  id: string
  username: string
  displayName: string
  avatar: string | null
  bio: string
  phone: string | null
}) {
  return { ...publicUser(u), phone: u.phone }
}

export function cookieOptions() {
  return {
    httpOnly: true,
    sameSite: 'lax' as const,
    path: '/',
    maxAge: 60 * 60 * 24 * 30,
  }
}
