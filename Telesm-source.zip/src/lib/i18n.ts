import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { Lang } from './types'

export const dict = {
  fa: {
    appName: 'تلسِم',
    tagline: 'پیام‌رسان سریع و امن، مثل تلگرام',
    welcome: 'خوش آمدی',
    login: 'ورود',
    register: 'ثبت‌نام',
    username: 'نام کاربری',
    usernameHint: 'فقط حروف انگلیسی، عدد و _',
    phone: 'شماره موبایل',
    phoneHint: 'مثلاً ۰۹۱۲ ۳۴۵ ۶۷۸۹',
    identifier: 'شماره موبایل یا نام کاربری',
    identifierPlaceholder: '0912... یا ali_2008',
    password: 'گذرواژه',
    displayName: 'نام نمایشی',
    displayNamePlaceholder: 'مثلاً: علی رضایی',
    bio: 'بیوگرافی',
    bioPlaceholder: 'درباره خودت بنویس...',
    loginTitle: 'ورود به تلسِم',
    registerTitle: 'ساخت حساب جدید',
    haveAccount: 'حساب داری؟ وارد شو',
    noAccount: 'حساب نداری؟ ثبت‌نام کن',
    chats: 'گفت‌وگوها',
    search: 'جستجو...',
    newChat: 'گفت‌وگوی جدید',
    newGroup: 'گروه جدید',
    typeMessage: 'پیامت رو بنویس...',
    online: 'آنلاین',
    offline: 'آفلاین',
    typing: 'در حال نوشتن...',
    typingMultiple: 'در حال نوشتن...',
    members: 'عضو',
    you: 'تو',
    save: 'ذخیره',
    cancel: 'انصراف',
    create: 'ساختن',
    editProfile: 'ویرایش پروفایل',
    myProfile: 'پروفایل من',
    logout: 'خروج',
    language: 'زبان',
    groupName: 'نام گروه',
    groupNamePlaceholder: 'مثلاً: دوستان کلاس',
    selectMembers: 'انتخاب اعضا',
    startChat: 'شروع گفت‌وگو',
    users: 'کاربرها',
    noChats: 'هنوز گفت‌وگویی نداری',
    noChatsHint: 'از دکمه بالا یک گفت‌وگوی جدید شروع کن',
    noMessages: 'اولین پیام رو بفرست!',
    noUsers: 'کاربری پیدا نشد',
    noResults: 'چیزی پیدا نشد',
    today: 'امروز',
    yesterday: 'دیروز',
    imageTooLarge: 'عکس خیلی بزرگه (حداکثر ۱.۵ مگابایت)',
    emptyMessage: 'پیام خالیه!',
    connectionLost: 'اتصال قطع شد...',
    connected: 'متصل',
    usernameTaken: 'این نام کاربری قبلاً گرفته شده',
    phoneTaken: 'این شماره قبلاً ثبت شده',
    invalidPhone: 'شماره موبایل معتبر نیست (مثل ۰۹۱۲۳۴۵۶۷۸۹)',
    wrongCredentials: 'شماره/نام کاربری یا گذرواژه اشتباهه',
    invalidUsername: 'نام کاربری باید ۳ تا ۲۰ کاراکتر انگلیسی/عدد باشه',
    shortPassword: 'گذرواژه حداقل ۴ کاراکتره',
    nameRequired: 'نام نمایشی الزامیه',
    groupNameRequired: 'نام گروه الزامیه',
    selectMemberFirst: 'حداقل یک عضو انتخاب کن',
    savedToast: 'پروفایل ذخیره شد',
    loginFailed: 'ورود ناموفق بود',
    registerFailed: 'ثبت‌نام ناموفق بود',
    loadFailed: 'بارگذاری ناموفق بود',
    seen: 'دیده شد',
    groupCreatedBy: 'گروه ساخته شد',
    photo: 'عکس',
    photoOf: 'عکس از',
    loading: 'در حال بارگذاری...',
    searchUsersHint: 'برای شروع چت، اسم کاربر رو جستجو کن',
    people: 'افراد',
    sendPic: 'ارسال عکس',
    emoji: 'ایموجی',
    andYou: 'و تو',
  },
  en: {
    appName: 'Telesm',
    tagline: 'Fast & secure messenger, like Telegram',
    welcome: 'Welcome',
    login: 'Log in',
    register: 'Sign up',
    username: 'Username',
    usernameHint: 'English letters, numbers and _ only',
    phone: 'Phone number',
    phoneHint: 'e.g. 0912 345 6789',
    identifier: 'Phone number or username',
    identifierPlaceholder: '0912... or alex_2008',
    password: 'Password',
    displayName: 'Display name',
    displayNamePlaceholder: 'e.g. Alex Carter',
    bio: 'Bio',
    bioPlaceholder: 'Write something about you...',
    loginTitle: 'Sign in to Telesm',
    registerTitle: 'Create a new account',
    haveAccount: 'Already have an account? Log in',
    noAccount: 'No account? Sign up',
    chats: 'Chats',
    search: 'Search...',
    newChat: 'New chat',
    newGroup: 'New group',
    typeMessage: 'Type a message...',
    online: 'online',
    offline: 'offline',
    typing: 'typing...',
    typingMultiple: 'typing...',
    members: 'members',
    you: 'You',
    save: 'Save',
    cancel: 'Cancel',
    create: 'Create',
    editProfile: 'Edit profile',
    myProfile: 'My profile',
    logout: 'Log out',
    language: 'Language',
    groupName: 'Group name',
    groupNamePlaceholder: 'e.g. Class Friends',
    selectMembers: 'Select members',
    startChat: 'Start chat',
    users: 'Users',
    noChats: 'No chats yet',
    noChatsHint: 'Start a new chat from the button above',
    noMessages: 'Send the first message!',
    noUsers: 'No users found',
    noResults: 'Nothing found',
    today: 'Today',
    yesterday: 'Yesterday',
    imageTooLarge: 'Image is too large',
    emptyMessage: 'Message is empty!',
    connectionLost: 'Connection lost...',
    connected: 'Connected',
    usernameTaken: 'This username is already taken',
    phoneTaken: 'This phone number is already registered',
    invalidPhone: 'Invalid phone number (e.g. 09123456789)',
    wrongCredentials: 'Wrong phone/username or password',
    invalidUsername: 'Username must be 3-20 English letters/digits',
    shortPassword: 'Password must be at least 4 characters',
    nameRequired: 'Display name is required',
    groupNameRequired: 'Group name is required',
    selectMemberFirst: 'Select at least one member',
    savedToast: 'Profile saved',
    loginFailed: 'Login failed',
    registerFailed: 'Signup failed',
    loadFailed: 'Failed to load',
    seen: 'Seen',
    groupCreatedBy: 'Group created',
    photo: 'Photo',
    photoOf: 'Photo from',
    loading: 'Loading...',
    searchUsersHint: 'Search a username to start chatting',
    people: 'People',
    sendPic: 'Send photo',
    emoji: 'Emoji',
    andYou: 'and you',
  },
} as const

export type DictKey = keyof (typeof dict)['fa']

export function t(lang: Lang, key: DictKey): string {
  return dict[lang][key] ?? dict.fa[key] ?? key
}

export function formatDateLabel(iso: string, lang: Lang): string {
  const d = new Date(iso)
  const now = new Date()
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  const day = new Date(d.getFullYear(), d.getMonth(), d.getDate())
  const diffDays = Math.round((startOfToday.getTime() - day.getTime()) / 86400000)
  if (diffDays === 0) return t(lang, 'today')
  if (diffDays === 1) return t(lang, 'yesterday')
  return d.toLocaleDateString(lang === 'fa' ? 'fa-IR' : 'en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  })
}

export function formatTime(iso: string, lang: Lang): string {
  return new Date(iso).toLocaleTimeString(lang === 'fa' ? 'fa-IR' : 'en-US', {
    hour: '2-digit',
    minute: '2-digit',
  })
}

export function formatChatTime(iso: string, lang: Lang): string {
  const d = new Date(iso)
  const now = new Date()
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  const day = new Date(d.getFullYear(), d.getMonth(), d.getDate())
  const diffDays = Math.round((startOfToday.getTime() - day.getTime()) / 86400000)
  if (diffDays === 0) return formatTime(iso, lang)
  if (diffDays < 7)
    return d.toLocaleDateString(lang === 'fa' ? 'fa-IR' : 'en-US', { weekday: 'short' })
  return d.toLocaleDateString(lang === 'fa' ? 'fa-IR' : 'en-US', {
    month: 'short',
    day: 'numeric',
  })
}

type LangState = {
  lang: Lang
  setLang: (l: Lang) => void
  toggle: () => void
}

export const useLang = create<LangState>()(
  persist(
    (set, get) => ({
      lang: 'fa',
      setLang: (lang) => set({ lang }),
      toggle: () => set({ lang: get().lang === 'fa' ? 'en' : 'fa' }),
    }),
    { name: 'glasschat-lang' }
  )
)
