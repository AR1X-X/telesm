'use client'

const AVATAR_GRADIENTS = [
  'from-violet-500 to-fuchsia-500',
  'from-fuchsia-500 to-pink-500',
  'from-purple-500 to-violet-600',
  'from-rose-500 to-fuchsia-600',
  'from-violet-600 to-indigo-400',
  'from-pink-500 to-violet-500',
  'from-fuchsia-600 to-purple-500',
  'from-purple-400 to-rose-400',
]

export function avatarGradient(id: string): string {
  let hash = 0
  for (let i = 0; i < id.length; i++) {
    hash = (hash * 31 + id.charCodeAt(i)) | 0
  }
  return AVATAR_GRADIENTS[Math.abs(hash) % AVATAR_GRADIENTS.length]
}

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/)
  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase()
  return name.slice(0, 2).toUpperCase()
}

/** Compress an image file to a data URL that fits within maxBytes. */
export async function fileToDataUrl(
  file: File,
  maxDim = 1280,
  quality = 0.75,
  maxBytes = 1_200_000
): Promise<string> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(reader.result as string)
    reader.onerror = reject
    reader.readAsDataURL(file)
  })

  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image()
    image.onload = () => resolve(image)
    image.onerror = reject
    image.src = dataUrl
  })

  let w = img.width
  let h = img.height
  const scale = Math.min(1, maxDim / Math.max(w, h))
  w = Math.max(1, Math.round(w * scale))
  h = Math.max(1, Math.round(h * scale))

  const canvas = document.createElement('canvas')
  canvas.width = w
  canvas.height = h
  const ctx = canvas.getContext('2d')!
  ctx.drawImage(img, 0, 0, w, h)

  let q = quality
  let out = canvas.toDataURL('image/jpeg', q)
  while (out.length * 0.75 > maxBytes && q > 0.35) {
    q -= 0.12
    out = canvas.toDataURL('image/jpeg', q)
  }
  if (out.length * 0.75 > maxBytes) {
    // shrink dimensions as a last resort
    const w2 = Math.round(w * 0.6)
    const h2 = Math.round(h * 0.6)
    canvas.width = w2
    canvas.height = h2
    canvas.getContext('2d')!.drawImage(img, 0, 0, w2, h2)
    out = canvas.toDataURL('image/jpeg', 0.5)
  }
  return out
}
