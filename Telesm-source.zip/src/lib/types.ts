export type Lang = 'fa' | 'en'

export type PublicUser = {
  id: string
  username: string
  displayName: string
  avatar: string | null
  bio: string
  /** only present on /api/auth/me (your own number) */
  phone?: string | null
}

export type ChatMessage = {
  id: string
  chatId: string
  senderId: string
  text: string | null
  image: string | null
  createdAt: string
  sender: PublicUser
  pending?: boolean
  failed?: boolean
  tempId?: string
}

export type ChatSummary = {
  id: string
  type: 'dm' | 'group'
  name: string | null
  avatar: string | null
  createdAt: string
  updatedAt: string
  members: PublicUser[]
  memberRead?: Record<string, string>
  lastMessage: {
    id: string
    text: string | null
    image: string | null
    createdAt: string
    senderId: string
    senderName: string
  } | null
  unreadCount: number
}

export type { PublicUser as Me }
