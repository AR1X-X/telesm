'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { Avatar } from './Avatar'
import { MessageBubble } from './MessageBubble'
import { ChatInput } from './ChatInput'
import { useLang, t } from '@/lib/i18n'
import { chatTitle, getPeer } from '@/store/chat-store'
import type { ChatMessage, ChatSummary, PublicUser } from '@/lib/types'
import { cn } from '@/lib/utils'
import { ArrowRight, UsersRound } from 'lucide-react'

type ChatWindowProps = {
  chat: ChatSummary
  me: PublicUser
  messages: ChatMessage[]
  onlineIds: Set<string>
  typingUsers: { displayName: string; at: number }[]
  peerLastReadAt?: string
  onBack: () => void
  onSend: (text: string, image: string | null) => void
  onTyping: (isTyping: boolean) => void
  onNotify: (msg: string) => void
}

export function ChatWindow({
  chat,
  me,
  messages,
  onlineIds,
  typingUsers,
  peerLastReadAt,
  onBack,
  onSend,
  onTyping,
  onNotify,
}: ChatWindowProps) {
  const { lang } = useLang()
  const [lightbox, setLightbox] = useState<string | null>(null)
  const bottomRef = useRef<HTMLDivElement>(null)
  const scrollRef = useRef<HTMLDivElement>(null)

  const peer = chat.type === 'dm' ? getPeer(chat, me.id) : null
  const isTyping = typingUsers.length > 0
  const online = peer ? onlineIds.has(peer.id) : false

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages.length, chat.id])

  const subtitle = useMemo(() => {
    if (isTyping) return t(lang, 'typing')
    if (chat.type === 'group') {
      const onlineCount = chat.members.filter((m) => onlineIds.has(m.id)).length
      return `${chat.members.length} ${t(lang, 'members')} · ${onlineCount} ${t(lang, 'online')}`
    }
    return online ? t(lang, 'online') : t(lang, 'offline')
  }, [chat, isTyping, online, onlineIds, lang, typingUsers.length])

  return (
    <div className="glass flex h-full min-h-0 flex-col md:rounded-e-3xl">
      {/* header */}
      <div className="flex items-center gap-3 border-b border-white/10 p-3.5">
        <button
          type="button"
          onClick={onBack}
          className="flex h-9 w-9 items-center justify-center rounded-xl text-white/70 transition hover:bg-white/10 md:hidden"
          aria-label="back"
        >
          <ArrowRight className="h-5 w-5 rtl:-scale-x-100" />
        </button>
        {chat.type === 'group' ? (
          <Avatar id={chat.id} name={chatTitle(chat, me.id, '')} src={chat.avatar} size={44} />
        ) : (
          <Avatar
            id={peer?.id ?? chat.id}
            name={peer?.displayName ?? '?'}
            src={peer?.avatar}
            size={44}
            online={peer ? online : undefined}
          />
        )}
        <div className="min-w-0 flex-1">
          <div className="truncate text-sm font-semibold text-white">
            {chatTitle(chat, me.id, t(lang, 'you'))}
          </div>
          <div
            className={cn(
              'truncate text-xs',
              isTyping ? 'text-fuchsia-300' : online ? 'text-emerald-300' : 'text-white/45'
            )}
          >
            {subtitle}
          </div>
        </div>
        {chat.type === 'group' && (
          <div className="hidden items-center gap-1 md:flex" title={chat.members.map((m) => m.displayName).join('، ')}>
            <UsersRound className="h-4 w-4 text-white/40" />
            <span className="text-xs text-white/45">{chat.members.length}</span>
          </div>
        )}
      </div>

      {/* messages */}
      <div ref={scrollRef} className="custom-scroll min-h-0 flex-1 space-y-1 overflow-y-auto px-3 py-4 md:px-6">
        {messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
            <div className="glass flex h-16 w-16 items-center justify-center rounded-3xl">
              <span className="text-3xl">💬</span>
            </div>
            <div className="text-sm font-medium text-white/60">{t(lang, 'noMessages')}</div>
          </div>
        ) : (
          messages.map((m, i) => (
            <MessageBubble
              key={m.id}
              message={m}
              chat={chat}
              me={me}
              prev={i > 0 ? messages[i - 1] : undefined}
              peerLastReadAt={peerLastReadAt}
              onImageClick={setLightbox}
            />
          ))
        )}
        <div ref={bottomRef} />
      </div>

      {/* input */}
      <ChatInput onSend={onSend} onTyping={onTyping} onNotify={onNotify} />

      {/* lightbox */}
      {lightbox && (
        <div
          className="fixed inset-0 z-50 flex cursor-zoom-out items-center justify-center bg-black/80 p-6 backdrop-blur-sm"
          onClick={() => setLightbox(null)}
        >
          { }
          <img src={lightbox} alt="photo" className="max-h-full max-w-full rounded-2xl object-contain" />
        </div>
      )}
    </div>
  )
}
