'use client'

import { useMemo, useRef, useState } from 'react'
import { Avatar } from './Avatar'
import { useLang, t, formatChatTime } from '@/lib/i18n'
import { chatTitle, getPeer } from '@/store/chat-store'
import type { ChatSummary, PublicUser } from '@/lib/types'
import { cn } from '@/lib/utils'
import {
  MessageCirclePlus,
  UsersRound,
  Globe,
  LogOut,
  Search,
  UserRound,
} from 'lucide-react'

type SidebarProps = {
  me: PublicUser
  chats: ChatSummary[]
  users: PublicUser[]
  activeChatId: string | null
  onlineIds: Set<string>
  typing: Record<string, Record<string, { displayName: string; at: number }>>
  onOpenChat: (chatId: string) => void
  onStartDm: (userId: string) => Promise<void>
  onNewChat: () => void
  onNewGroup: () => void
  onProfile: () => void
  onLogout: () => void
  onToggleLang: () => void
}

export function Sidebar({
  me,
  chats,
  users,
  activeChatId,
  onlineIds,
  typing,
  onOpenChat,
  onStartDm,
  onNewChat,
  onNewGroup,
  onProfile,
  onLogout,
  onToggleLang,
}: SidebarProps) {
  const { lang } = useLang()
  const [query, setQuery] = useState('')
  const searchRef = useRef<HTMLInputElement>(null)

  const filteredChats = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return chats
    return chats.filter((c) => {
      const title = chatTitle(c, me.id, t(lang, 'you')).toLowerCase()
      const inTitle = title.includes(q)
      const inLast = c.lastMessage?.text?.toLowerCase().includes(q) ?? false
      return inTitle || inLast
    })
  }, [chats, query, me.id, lang])

  const matchedUsers = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return []
    return users
      .filter((u) => !chats.some((c) => c.type === 'dm' && c.members.some((m) => m.id === u.id)))
      .filter(
        (u) =>
          u.displayName.toLowerCase().includes(q) || u.username.toLowerCase().includes(q)
      )
      .slice(0, 8)
  }, [users, chats, query])

  const preview = (chat: ChatSummary): string => {
    const typingUsers = Object.values(typing[chat.id] ?? {})
    if (typingUsers.length > 0) {
      return chat.type === 'group'
        ? `${typingUsers[0].displayName}: ${t(lang, 'typing')}`
        : t(lang, 'typing')
    }
    const lm = chat.lastMessage
    if (!lm) return t(lang, 'noMessages')
    const prefix =
      chat.type === 'group' ? (lm.senderId === me.id ? `${t(lang, 'you')}: ` : `${lm.senderName}: `) : lm.senderId === me.id ? `${t(lang, 'you')}: ` : ''
    if (lm.image && !lm.text) return `${prefix}📷 ${t(lang, 'photo')}`
    return prefix + (lm.text || '')
  }

  return (
    <aside className="glass flex h-full min-h-0 flex-col md:rounded-s-3xl">
      {/* header */}
      <div className="flex items-center gap-3 border-b border-white/10 p-4">
        <button type="button" onClick={onProfile} aria-label={t(lang, 'myProfile')}>
          <Avatar id={me.id} name={me.displayName} src={me.avatar} size={44} online />
        </button>
        <div className="min-w-0 flex-1">
          <div className="truncate text-sm font-semibold text-white">{me.displayName}</div>
          <div dir="ltr" className="truncate text-xs text-white/45 text-start">@{me.username}</div>
        </div>
        <button
          type="button"
          onClick={onToggleLang}
          title={t(lang, 'language')}
          className="flex h-9 w-9 items-center justify-center rounded-xl text-white/60 transition hover:bg-white/10 hover:text-white"
        >
          <Globe className="h-5 w-5" />
        </button>
        <button
          type="button"
          onClick={onLogout}
          title={t(lang, 'logout')}
          className="flex h-9 w-9 items-center justify-center rounded-xl text-white/60 transition hover:bg-white/10 hover:text-rose-300"
        >
          <LogOut className="h-5 w-5" />
        </button>
      </div>

      {/* actions + search */}
      <div className="space-y-2 p-3">
        <div className="flex gap-2">
          <button
            type="button"
            onClick={onNewChat}
            className="glass flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-xs font-medium text-white/80 transition hover:bg-white/15"
          >
            <MessageCirclePlus className="h-4 w-4 text-fuchsia-300" />
            {t(lang, 'newChat')}
          </button>
          <button
            type="button"
            onClick={onNewGroup}
            className="glass flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-xs font-medium text-white/80 transition hover:bg-white/15"
          >
            <UsersRound className="h-4 w-4 text-fuchsia-300" />
            {t(lang, 'newGroup')}
          </button>
        </div>
        <div className="relative">
          <Search className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/40" />
          <input
            ref={searchRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t(lang, 'search')}
            className="glass-input h-10 w-full rounded-xl ps-9 pe-3 text-sm text-white placeholder:text-white/35"
          />
        </div>
      </div>

      {/* chat list */}
      <div className="custom-scroll min-h-0 flex-1 space-y-1 overflow-y-auto px-3 pb-4">
        {filteredChats.length === 0 && !matchedUsers.length && (
          <div className="mt-10 space-y-2 px-4 text-center">
            <UserRound className="mx-auto h-10 w-10 text-white/20" />
            <div className="text-sm font-medium text-white/60">{t(lang, 'noChats')}</div>
            <div className="text-xs text-white/35">{t(lang, 'noChatsHint')}</div>
          </div>
        )}

        {filteredChats.map((chat) => {
          const isActive = chat.id === activeChatId
          const peer = chat.type === 'dm' ? getPeer(chat, me.id) : null
          const isTyping = Object.keys(typing[chat.id] ?? {}).length > 0
          return (
            <button
              key={chat.id}
              type="button"
              onClick={() => onOpenChat(chat.id)}
              className={cn(
                'flex w-full items-center gap-3 rounded-2xl p-2.5 text-start transition',
                isActive ? 'bg-white/15 ring-1 ring-white/20' : 'hover:bg-white/8'
              )}
            >
              {chat.type === 'group' ? (
                <Avatar id={chat.id} name={chatTitle(chat, me.id, '')} src={chat.avatar} size={48} />
              ) : (
                <Avatar
                  id={peer?.id ?? chat.id}
                  name={peer?.displayName ?? '?'}
                  src={peer?.avatar}
                  size={48}
                  online={peer ? onlineIds.has(peer.id) : undefined}
                />
              )}
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate text-sm font-semibold text-white">
                    {chatTitle(chat, me.id, t(lang, 'you'))}
                  </span>
                  {chat.lastMessage && (
                    <span className="shrink-0 text-[10px] text-white/40">
                      {formatChatTime(chat.lastMessage.createdAt, lang)}
                    </span>
                  )}
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span
                    className={cn(
                      'truncate text-xs',
                      isTyping ? 'text-fuchsia-300' : 'text-white/50'
                    )}
                  >
                    {preview(chat)}
                  </span>
                  {chat.unreadCount > 0 && (
                    <span className="flex h-5 min-w-5 shrink-0 items-center justify-center rounded-full bg-gradient-to-r from-violet-500 to-fuchsia-500 px-1.5 text-[10px] font-bold text-white">
                      {chat.unreadCount}
                    </span>
                  )}
                </div>
              </div>
            </button>
          )
        })}

        {matchedUsers.length > 0 && (
          <>
            <div className="px-2 pt-3 pb-1 text-[11px] font-medium uppercase tracking-wide text-white/35">
              {t(lang, 'people')}
            </div>
            {matchedUsers.map((u) => (
              <button
                key={u.id}
                type="button"
                onClick={() => {
                  onStartDm(u.id)
                  setQuery('')
                }}
                className="flex w-full items-center gap-3 rounded-2xl p-2.5 text-start transition hover:bg-white/8"
              >
                <Avatar id={u.id} name={u.displayName} src={u.avatar} size={42} online={onlineIds.has(u.id)} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-medium text-white">{u.displayName}</div>
                  <div dir="ltr" className="truncate text-xs text-white/45 text-start">@{u.username}</div>
                </div>
                <MessageCirclePlus className="h-4 w-4 text-fuchsia-300" />
              </button>
            ))}
          </>
        )}
      </div>

      {/* footer hint */}
      <div className="border-t border-white/10 px-4 py-2.5 text-center text-[10px] text-white/30">
        {t(lang, 'appName')} · {t(lang, 'tagline')}
      </div>
    </aside>
  )
}
