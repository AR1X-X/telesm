'use client'

import { useEffect, useMemo, useState } from 'react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Avatar } from './Avatar'
import { useLang, t } from '@/lib/i18n'
import type { PublicUser } from '@/lib/types'
import { Search, MessageCirclePlus, Loader2 } from 'lucide-react'

type NewChatDialogProps = {
  open: boolean
  onOpenChange: (open: boolean) => void
  users: PublicUser[]
  onStart: (userId: string) => Promise<void>
}

export function NewChatDialog({ open, onOpenChange, users, onStart }: NewChatDialogProps) {
  const { lang } = useLang()
  const [query, setQuery] = useState('')
  const [starting, setStarting] = useState<string | null>(null)

  useEffect(() => {
    if (open) setQuery('')
  }, [open])

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return users
    return users.filter(
      (u) =>
        u.displayName.toLowerCase().includes(q) || u.username.toLowerCase().includes(q)
    )
  }, [users, query])

  const start = async (userId: string) => {
    setStarting(userId)
    try {
      await onStart(userId)
      onOpenChange(false)
    } finally {
      setStarting(null)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-strong border-white/15 sm:rounded-3xl" aria-describedby={undefined}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-white">
            <MessageCirclePlus className="h-5 w-5 text-fuchsia-300" />
            {t(lang, 'newChat')}
          </DialogTitle>
        </DialogHeader>

        <div className="relative">
          <Search className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/40" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t(lang, 'search')}
            className="glass-input ps-9 text-start"
          />
        </div>

        <div className="custom-scroll max-h-80 space-y-1 overflow-y-auto pe-1">
          {filtered.length === 0 ? (
            <div className="py-8 text-center text-sm text-white/40">
              {users.length === 0 ? t(lang, 'noUsers') : t(lang, 'noResults')}
            </div>
          ) : (
            filtered.map((u) => (
              <button
                key={u.id}
                type="button"
                onClick={() => start(u.id)}
                className="flex w-full items-center gap-3 rounded-2xl p-2.5 text-start transition hover:bg-white/10"
              >
                <Avatar id={u.id} name={u.displayName} src={u.avatar} size={42} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-medium text-white">{u.displayName}</div>
                  <div dir="ltr" className="truncate text-xs text-white/45 text-start">
                    @{u.username}
                  </div>
                </div>
                {starting === u.id && (
                  <Loader2 className="h-4 w-4 animate-spin text-fuchsia-300" />
                )}
              </button>
            ))
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
