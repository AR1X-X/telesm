'use client'

import { useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { EmojiPicker } from './EmojiPicker'
import { useLang, t } from '@/lib/i18n'
import { fileToDataUrl } from '@/lib/media'
import { ImagePlus, Loader2, SendHorizonal, Smile } from 'lucide-react'

type ChatInputProps = {
  disabled?: boolean
  onSend: (text: string, image: string | null) => void
  onTyping: (isTyping: boolean) => void
  onNotify: (msg: string) => void
}

export function ChatInput({ disabled, onSend, onTyping, onNotify }: ChatInputProps) {
  const { lang } = useLang()
  const [text, setText] = useState('')
  const [image, setImage] = useState<string | null>(null)
  const [showEmoji, setShowEmoji] = useState(false)
  const [uploading, setUploading] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  const typingRef = useRef(false)

  const handleTyping = (value: string) => {
    setText(value)
    if (!typingRef.current && value.length > 0) {
      typingRef.current = true
      onTyping(true)
    }
    if (typingRef.current && value.length === 0) {
      typingRef.current = false
      onTyping(false)
    }
  }

  const stopTypingSoon = () => {
    window.setTimeout(() => {
      if (typingRef.current) {
        typingRef.current = false
        onTyping(false)
      }
    }, 2500)
  }

  const doSend = () => {
    const value = text.trim()
    if (!value && !image) return
    onSend(value, image)
    setText('')
    setImage(null)
    setShowEmoji(false)
    if (typingRef.current) {
      typingRef.current = false
      onTyping(false)
    }
  }

  const pickImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setUploading(true)
    try {
      const dataUrl = await fileToDataUrl(file)
      setImage(dataUrl)
    } catch {
      onNotify(t(lang, 'imageTooLarge'))
    } finally {
      setUploading(false)
      e.target.value = ''
    }
  }

  return (
    <div className="relative border-t border-white/10 p-3">
      {showEmoji && (
        <EmojiPicker
          onPick={(emoji) => handleTyping(text + emoji)}
          onClose={() => setShowEmoji(false)}
        />
      )}

      {image && (
        <div className="glass mb-2 flex items-center gap-3 rounded-2xl p-2">
          { }
          <img src={image} alt="preview" className="h-14 w-14 rounded-xl object-cover" />
          <span className="flex-1 text-xs text-white/60">{t(lang, 'sendPic')}</span>
          <button
            type="button"
            onClick={() => setImage(null)}
            className="rounded-lg px-2 py-1 text-xs text-rose-300 transition hover:bg-white/10"
          >
            ✕
          </button>
        </div>
      )}

      <div className="flex items-end gap-2">
        <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={pickImage} />
        <button
          type="button"
          disabled={disabled || uploading}
          onClick={() => fileRef.current?.click()}
          title={t(lang, 'sendPic')}
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl text-white/60 transition hover:bg-white/10 hover:text-fuchsia-300"
        >
          {uploading ? <Loader2 className="h-5 w-5 animate-spin" /> : <ImagePlus className="h-5 w-5" />}
        </button>
        <button
          type="button"
          disabled={disabled}
          onClick={() => setShowEmoji((v) => !v)}
          title={t(lang, 'emoji')}
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl text-white/60 transition hover:bg-white/10 hover:text-fuchsia-300"
        >
          <Smile className="h-5 w-5" />
        </button>
        <textarea
          value={text}
          disabled={disabled}
          onChange={(e) => {
            handleTyping(e.target.value)
            stopTypingSoon()
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault()
              doSend()
            }
          }}
          placeholder={t(lang, 'typeMessage')}
          rows={1}
          className="glass-input custom-scroll max-h-32 min-h-11 flex-1 resize-none rounded-2xl px-4 py-3 text-sm text-white placeholder:text-white/35"
        />
        <Button
          type="button"
          disabled={disabled || (!text.trim() && !image)}
          onClick={doSend}
          className="h-11 w-11 shrink-0 rounded-2xl bg-gradient-to-r from-violet-500 to-fuchsia-500 p-0 text-white shadow-lg shadow-fuchsia-500/25 hover:opacity-90"
          aria-label="send"
        >
          <SendHorizonal className="h-5 w-5 rtl:-scale-x-100" />
        </Button>
      </div>
    </div>
  )
}
