'use client'

import { useState } from 'react'
import { EMOJI_CATEGORIES } from './emoji-data'
import { cn } from '@/lib/utils'

type EmojiPickerProps = {
  onPick: (emoji: string) => void
  onClose: () => void
}

export function EmojiPicker({ onPick, onClose }: EmojiPickerProps) {
  const [cat, setCat] = useState(0)

  return (
    <div className="glass-strong absolute bottom-14 start-0 z-30 w-[300px] rounded-2xl p-3 shadow-2xl animate-pop">
      <div className="mb-2 flex gap-1 overflow-x-auto pb-1">
        {EMOJI_CATEGORIES.map((c, i) => (
          <button
            key={c.name}
            type="button"
            onClick={() => setCat(i)}
            className={cn(
              'flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-lg transition',
              i === cat ? 'bg-white/25' : 'hover:bg-white/10'
            )}
            aria-label={c.name}
          >
            {c.icon}
          </button>
        ))}
      </div>
      <div className="grid max-h-52 grid-cols-8 gap-0.5 overflow-y-auto custom-scroll">
        {EMOJI_CATEGORIES[cat].emojis.map((e, i) => (
          <button
            key={`${e}-${i}`}
            type="button"
            onClick={() => onPick(e)}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-xl transition hover:scale-125 hover:bg-white/10"
          >
            {e}
          </button>
        ))}
      </div>
      <div className="mt-1 text-end">
        <button
          type="button"
          onClick={onClose}
          className="text-[11px] text-white/50 transition hover:text-white/80"
        >
          ✕
        </button>
      </div>
    </div>
  )
}
