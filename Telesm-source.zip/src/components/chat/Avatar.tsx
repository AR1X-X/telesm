'use client'

import { avatarGradient, initials } from '@/lib/media'
import { cn } from '@/lib/utils'

type AvatarProps = {
  id: string
  name: string
  src?: string | null
  size?: number
  online?: boolean
  className?: string
}

export function Avatar({ id, name, src, size = 44, online, className }: AvatarProps) {
  return (
    <div className={cn('relative shrink-0', className)} style={{ width: size, height: size }}>
      {src ? (
         
        <img
          src={src}
          alt={name}
          className="h-full w-full rounded-full object-cover ring-1 ring-white/25"
        />
      ) : (
        <div
          className={cn(
            'flex h-full w-full items-center justify-center rounded-full bg-gradient-to-br font-semibold text-white ring-1 ring-white/25',
            avatarGradient(id)
          )}
          style={{ fontSize: size * 0.36 }}
        >
          {initials(name)}
        </div>
      )}
      {online !== undefined && (
        <span
          className={cn(
            'absolute bottom-0 end-0 block rounded-full ring-2 ring-[#1d0f3a] transition-colors',
            online ? 'bg-emerald-400' : 'bg-white/30'
          )}
          style={{ width: size * 0.26, height: size * 0.26 }}
        />
      )}
    </div>
  )
}
