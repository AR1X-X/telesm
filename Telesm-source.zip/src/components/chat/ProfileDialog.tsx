'use client'

import { useRef, useState } from 'react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Avatar } from './Avatar'
import { useLang, t } from '@/lib/i18n'
import { fileToDataUrl } from '@/lib/media'
import type { PublicUser } from '@/lib/types'
import { Camera, Loader2 } from 'lucide-react'

type ProfileDialogProps = {
  open: boolean
  onOpenChange: (open: boolean) => void
  me: PublicUser
  onSaved: (user: PublicUser) => void
  onNotify: (msg: string) => void
}

export function ProfileDialog({ open, onOpenChange, me, onSaved, onNotify }: ProfileDialogProps) {
  const { lang } = useLang()
  const [displayName, setDisplayName] = useState(me.displayName)
  const [bio, setBio] = useState(me.bio || '')
  const [avatar, setAvatar] = useState<string | null>(me.avatar)
  const [saving, setSaving] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  const pickAvatar = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    try {
      const dataUrl = await fileToDataUrl(file, 256, 0.8, 250_000)
      setAvatar(dataUrl)
    } catch {
      onNotify(t(lang, 'imageTooLarge'))
    }
    e.target.value = ''
  }

  const save = async () => {
    if (!displayName.trim()) {
      onNotify(t(lang, 'nameRequired'))
      return
    }
    setSaving(true)
    try {
      const res = await fetch('/api/profile', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ displayName: displayName.trim(), bio, avatar }),
      })
      const data = await res.json()
      if (res.ok) {
        onSaved(data.user)
        onNotify(t(lang, 'savedToast'))
        onOpenChange(false)
      } else {
        onNotify(t(lang, 'loadFailed'))
      }
    } catch {
      onNotify(t(lang, 'connectionLost'))
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-strong border-white/15 sm:rounded-3xl" aria-describedby={undefined}>
        <DialogHeader>
          <DialogTitle className="text-white">{t(lang, 'myProfile')}</DialogTitle>
        </DialogHeader>

        <div className="flex flex-col items-center gap-3 py-2">
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="group relative"
            aria-label={t(lang, 'photo')}
          >
            <Avatar id={me.id} name={displayName || me.username} src={avatar} size={88} />
            <div className="absolute inset-0 flex items-center justify-center rounded-full bg-black/45 opacity-0 transition group-hover:opacity-100">
              <Camera className="h-7 w-7 text-white" />
            </div>
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={pickAvatar}
          />
          <div dir="ltr" className="text-xs text-white/50">@{me.username}</div>
        </div>

        <div className="space-y-3">
          <div className="space-y-1">
            <label className="text-xs text-white/60">{t(lang, 'displayName')}</label>
            <Input
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="glass-input text-start"
              maxLength={40}
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs text-white/60">{t(lang, 'bio')}</label>
            <Textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder={t(lang, 'bioPlaceholder')}
              className="glass-input min-h-[70px] resize-none text-start"
              maxLength={160}
            />
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="ghost"
            onClick={() => onOpenChange(false)}
            className="text-white/70 hover:bg-white/10 hover:text-white"
          >
            {t(lang, 'cancel')}
          </Button>
          <Button
            onClick={save}
            disabled={saving}
            className="bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white hover:opacity-90"
          >
            {saving && <Loader2 className="me-1 h-4 w-4 animate-spin" />}
            {t(lang, 'save')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
