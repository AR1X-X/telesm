'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useLang, t } from '@/lib/i18n'
import type { PublicUser } from '@/lib/types'
import { Globe, Loader2, Sparkles, Users, Zap, ShieldCheck, Send, Smartphone } from 'lucide-react'

type AuthScreenProps = {
  onAuthed: (user: PublicUser) => void
}

const KNOWN_ERRORS = [
  'usernameTaken',
  'phoneTaken',
  'invalidPhone',
  'wrongCredentials',
  'invalidUsername',
  'shortPassword',
  'nameRequired',
] as const

export function AuthScreen({ onAuthed }: AuthScreenProps) {
  const { lang, toggle } = useLang()
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [identifier, setIdentifier] = useState('')
  const [phone, setPhone] = useState('')
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [displayName, setDisplayName] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const url = mode === 'login' ? '/api/auth/login' : '/api/auth/register'
      const body =
        mode === 'login'
          ? { identifier, password }
          : { phone, username, password, displayName }
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })
      const data = await res.json()
      if (!res.ok) {
        const errKey = (data.error || 'loginFailed') as string
        setError(
          t(lang, (KNOWN_ERRORS as readonly string[]).includes(errKey)
            ? (errKey as (typeof KNOWN_ERRORS)[number])
            : mode === 'login'
              ? 'loginFailed'
              : 'registerFailed')
        )
        return
      }
      onAuthed(data.user)
    } catch {
      setError(t(lang, 'connectionLost'))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="relative flex min-h-dvh items-center justify-center p-4">
      {/* floating language toggle */}
      <button
        type="button"
        onClick={toggle}
        className="glass absolute top-5 end-5 z-10 flex items-center gap-2 rounded-full px-4 py-2 text-sm text-white/80 transition hover:bg-white/15"
      >
        <Globe className="h-4 w-4" />
        {lang === 'fa' ? 'English' : 'فارسی'}
      </button>

      <div className="grid w-full max-w-4xl items-center gap-10 md:grid-cols-2">
        {/* Brand side */}
        <div className="hidden flex-col gap-6 md:flex">
          <div className="flex items-center gap-3">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-sky-400 via-violet-500 to-fuchsia-500 shadow-lg shadow-fuchsia-500/30">
              <Send className="h-7 w-7 -translate-x-px translate-y-px text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">{t(lang, 'appName')}</h1>
              <p className="text-sm text-white/60">{t(lang, 'tagline')}</p>
            </div>
          </div>
          <div className="space-y-4">
            {[
              { icon: Smartphone, fa: 'ثبت‌نام و ورود با شماره موبایل', en: 'Sign up & log in with your phone number' },
              { icon: Zap, fa: 'پیام‌رسانی زنده با سوکت', en: 'Live messaging over sockets' },
              { icon: Users, fa: 'گروه‌ها و چت خصوصی', en: 'Groups & private chats' },
              { icon: Sparkles, fa: 'ایموجی، عکس و تایپ زنده', en: 'Emoji, photos & live typing' },
              { icon: ShieldCheck, fa: 'حساب کاربری شخصی امن', en: 'Secure personal accounts' },
            ].map((f) => (
              <div key={f.en} className="flex items-center gap-3 text-white/75">
                <div className="glass flex h-10 w-10 items-center justify-center rounded-xl">
                  <f.icon className="h-5 w-5 text-fuchsia-300" />
                </div>
                <span className="text-sm">{lang === 'fa' ? f.fa : f.en}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Form side */}
        <div className="glass-strong mx-auto w-full max-w-md rounded-3xl p-7 shadow-2xl">
          <div className="mb-6 flex items-center gap-3 md:hidden">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-sky-400 via-violet-500 to-fuchsia-500">
              <Send className="h-6 w-6 -translate-x-px translate-y-px text-white" />
            </div>
            <div>
              <div className="text-xl font-bold text-white">{t(lang, 'appName')}</div>
              <div className="text-xs text-white/60">{t(lang, 'tagline')}</div>
            </div>
          </div>

          <div className="glass mb-5 grid grid-cols-2 gap-1 rounded-xl p-1">
            {(['login', 'register'] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => {
                  setMode(m)
                  setError('')
                }}
                className={`rounded-lg py-2 text-sm font-medium transition ${
                  mode === m
                    ? 'bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white shadow'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                {t(lang, m)}
              </button>
            ))}
          </div>

          <h2 className="mb-4 text-lg font-semibold text-white">
            {t(lang, mode === 'login' ? 'loginTitle' : 'registerTitle')}
          </h2>

          <form onSubmit={submit} className="space-y-3">
            {mode === 'login' ? (
              <div className="space-y-1">
                <label className="text-xs text-white/60" htmlFor="identifier">
                  {t(lang, 'identifier')}
                </label>
                <Input
                  id="identifier"
                  dir="ltr"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder={t(lang, 'identifierPlaceholder')}
                  className="glass-input h-11 text-start"
                  autoComplete="username"
                  required
                />
              </div>
            ) : (
              <>
                <div className="space-y-1">
                  <label className="text-xs text-white/60" htmlFor="phone">
                    {t(lang, 'phone')}
                  </label>
                  <Input
                    id="phone"
                    dir="ltr"
                    type="tel"
                    inputMode="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="0912 345 6789"
                    className="glass-input h-11 text-start"
                    autoComplete="tel"
                    required
                  />
                  <p className="text-[11px] text-white/40">{t(lang, 'phoneHint')}</p>
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-white/60" htmlFor="displayName">
                    {t(lang, 'displayName')}
                  </label>
                  <Input
                    id="displayName"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder={t(lang, 'displayNamePlaceholder')}
                    className="glass-input h-11 text-start"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-white/60" htmlFor="username">
                    {t(lang, 'username')}
                  </label>
                  <Input
                    id="username"
                    dir="ltr"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="ali_2008"
                    className="glass-input h-11 text-start"
                    required
                  />
                  <p className="text-[11px] text-white/40">{t(lang, 'usernameHint')}</p>
                </div>
              </>
            )}

            <div className="space-y-1">
              <label className="text-xs text-white/60" htmlFor="password">
                {t(lang, 'password')}
              </label>
              <Input
                id="password"
                dir="ltr"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••"
                className="glass-input h-11 text-start"
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                required
              />
            </div>

            {error && (
              <div className="rounded-xl border border-rose-400/30 bg-rose-500/15 px-3 py-2 text-xs text-rose-200">
                {error}
              </div>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="h-11 w-full bg-gradient-to-r from-sky-400 via-violet-500 to-fuchsia-500 text-base font-semibold text-white shadow-lg shadow-fuchsia-500/25 transition hover:opacity-90"
            >
              {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : t(lang, mode)}
            </Button>
          </form>

          <button
            type="button"
            onClick={() => {
              setMode(mode === 'login' ? 'register' : 'login')
              setError('')
            }}
            className="mt-4 w-full text-center text-xs text-white/50 transition hover:text-white/80"
          >
            {t(lang, mode === 'login' ? 'noAccount' : 'haveAccount')}
          </button>

          <a
            href="/admin"
            className="mt-3 block w-full text-center text-[11px] text-white/30 transition hover:text-white/60"
          >
            {lang === 'fa' ? 'پنل مدیریت' : 'Admin panel'}
          </a>
        </div>
      </div>
    </div>
  )
}
