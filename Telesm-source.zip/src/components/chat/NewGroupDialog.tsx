'use client'

import { useEffect, useMemo, useState } from 'react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Checkbox } from '@/components/ui/checkbox'
import { Avatar } from './Avatar'
import { useLang, t } from '@/lib/i18n'
import type { PublicUser } from '@/lib/types'
import { UsersRound, Loader2, Check } from 'lucide-react'

type NewGroupDialogProps = {
  open: boolean
  onOpenChange: (open: boolean) => void
  users: PublicUser[]
  onCreate: (name: string, memberIds: string[]) => Promise<void>
  onNotify: (msg: string) => void
}

export function NewGroupDialog({ open, onOpenChange, users, onCreate, onNotify }: NewGroupDialogProps) {
  const { lang } = useLang()
  const [name, setName] = useState('')
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [creating, setCreating] = useState(false)

  useEffect(() => {
    if (open) {
      setName('')
      setSelected(new Set())
    }
  }, [open])

  const toggle = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const create = async () => {
    if (!name.trim()) {
      onNotify(t(lang, 'groupNameRequired'))
      return
    }
    if (selected.size === 0) {
      onNotify(t(lang, 'selectMemberFirst'))
      return
    }
    setCreating(true)
    try {
      await onCreate(name.trim(), Array.from(selected))
      onOpenChange(false)
    } finally {
      setCreating(false)
    }
  }

  const sorted = useMemo(() => users, [users])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-strong border-white/15 sm:rounded-3xl" aria-describedby={undefined}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-white">
            <UsersRound className="h-5 w-5 text-fuchsia-300" />
            {t(lang, 'newGroup')}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-3">
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={t(lang, 'groupNamePlaceholder')}
            className="glass-input text-start"
            maxLength={50}
          />
          <div className="text-xs text-white/50">{t(lang, 'selectMembers')}</div>
          <div className="custom-scroll max-h-64 space-y-1 overflow-y-auto pe-1">
            {sorted.length === 0 ? (
              <div className="py-8 text-center text-sm text-white/40">{t(lang, 'noUsers')}</div>
            ) : (
              sorted.map((u) => {
                const isSel = selected.has(u.id)
                return (
                  <div
                    key={u.id}
                    role="button"
                    tabIndex={0}
                    onClick={() => toggle(u.id)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault()
                        toggle(u.id)
                      }
                    }}
                    className={`flex w-full cursor-pointer items-center gap-3 rounded-2xl p-2.5 text-start transition ${
                      isSel ? 'bg-fuchsia-500/20 ring-1 ring-fuchsia-400/40' : 'hover:bg-white/10'
                    }`}
                  >
                    <Checkbox
                      checked={isSel}
                      tabIndex={-1}
                      className="pointer-events-none border-white/40 data-[state=checked]:border-fuchsia-400 data-[state=checked]:bg-fuchsia-500"
                    />
                    <Avatar id={u.id} name={u.displayName} src={u.avatar} size={38} />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium text-white">{u.displayName}</div>
                      <div dir="ltr" className="truncate text-xs text-white/45 text-start">
                        @{u.username}
                      </div>
                    </div>
                    {isSel && <Check className="h-4 w-4 text-fuchsia-300" />}
                  </div>
                )
              })
            )}
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="ghost"
            onClick={() => onOpenChange(false)}
            className="text-white/70 hover:bg-white/10 hover:text-white"
          >
            {t(lang, 'cancel')}
          </Button>
          <Button
            onClick={create}
            disabled={creating}
            className="bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white hover:opacity-90"
          >
            {creating && <Loader2 className="me-1 h-4 w-4 animate-spin" />}
            {t(lang, 'create')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
