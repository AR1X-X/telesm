'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Sidebar } from './Sidebar'
import { ChatWindow } from './ChatWindow'
import { ProfileDialog } from './ProfileDialog'
import { NewChatDialog } from './NewChatDialog'
import { NewGroupDialog } from './NewGroupDialog'
import { getSocket, destroySocket } from '@/lib/socket'
import { useLang, t } from '@/lib/i18n'
import { useChatStore, chatTitle } from '@/store/chat-store'
import type { ChatMessage, ChatSummary, PublicUser } from '@/lib/types'
import { cn } from '@/lib/utils'
import { WifiOff } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

type ChatAppProps = {
  initialMe: PublicUser
  onLogout: () => void
}

export function ChatApp({ initialMe, onLogout }: ChatAppProps) {
  const { lang, toggle } = useLang()
  const { toast } = useToast()

  const me = useChatStore((s) => s.me) ?? initialMe
  const setMe = useChatStore((s) => s.setMe)
  const chats = useChatStore((s) => s.chats)
  const setChats = useChatStore((s) => s.setChats)
  const upsertChat = useChatStore((s) => s.upsertChat)
  const activeChatId = useChatStore((s) => s.activeChatId)
  const setActiveChatId = useChatStore((s) => s.setActiveChatId)
  const messages = useChatStore((s) => s.messages)
  const setMessages = useChatStore((s) => s.setMessages)
  const addMessage = useChatStore((s) => s.addMessage)
  const replaceTemp = useChatStore((s) => s.replaceTemp)
  const onlineIds = useChatStore((s) => s.onlineIds)
  const setOnlineIds = useChatStore((s) => s.setOnlineIds)
  const setOnline = useChatStore((s) => s.setOnline)
  const typing = useChatStore((s) => s.typing)
  const setTyping = useChatStore((s) => s.setTyping)
  const users = useChatStore((s) => s.users)
  const setUsers = useChatStore((s) => s.setUsers)
  const lastRead = useChatStore((s) => s.lastRead)
  const setLastRead = useChatStore((s) => s.setLastRead)

  const [connected, setConnected] = useState(true)
  const [profileOpen, setProfileOpen] = useState(false)
  const [newChatOpen, setNewChatOpen] = useState(false)
  const [newGroupOpen, setNewGroupOpen] = useState(false)

  const socketRef = useRef<ReturnType<typeof getSocket> | null>(null)
  const activeChatIdRef = useRef<string | null>(null)

  useEffect(() => {
    activeChatIdRef.current = activeChatId
  }, [activeChatId])

  const notify = useCallback(
    (description: string) => {
      toast({ description, className: 'glass-toast' })
    },
    [toast]
  )

  // ---------------------------------------------------------------------
  // dir / lang
  // ---------------------------------------------------------------------
  useEffect(() => {
    document.documentElement.lang = lang
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr'
  }, [lang])

  // ---------------------------------------------------------------------
  // initial data
  // ---------------------------------------------------------------------
  const loadChats = useCallback(async () => {
    try {
      const res = await fetch('/api/chats')
      if (res.ok) {
        const data = await res.json()
        setChats(data.chats)
      }
    } catch {
      /* ignore */
    }
  }, [setChats])

  const loadUsers = useCallback(async () => {
    try {
      const res = await fetch('/api/users')
      if (res.ok) {
        const data = await res.json()
        setUsers(data.users)
      }
    } catch {
      /* ignore */
    }
  }, [setUsers])

  useEffect(() => {
    setMe(initialMe)
    loadChats()
    loadUsers()
  }, [initialMe, setMe, loadChats, loadUsers])

  // ---------------------------------------------------------------------
  // helpers to update chat list from a message
  // ---------------------------------------------------------------------
  const applyNewMessage = useCallback(
    (msg: ChatMessage, tempId: string | null) => {
      const state = useChatStore.getState()
      if (tempId && msg.senderId === state.me?.id) {
        replaceTemp(msg.chatId, tempId, msg)
      } else {
        addMessage(msg)
      }

      // update chat list
      const existing = state.chats.find((c) => c.id === msg.chatId)
      if (!existing) {
        loadChats()
        return
      }
      const isActive =
        activeChatIdRef.current === msg.chatId && typeof document !== 'undefined' && !document.hidden
      const updated: ChatSummary = {
        ...existing,
        updatedAt: new Date().toISOString(),
        lastMessage: {
          id: msg.id,
          text: msg.text,
          image: msg.image,
          createdAt: msg.createdAt,
          senderId: msg.senderId,
          senderName: msg.sender.displayName,
        },
        unreadCount:
          msg.senderId === state.me?.id
            ? existing.unreadCount
            : isActive
              ? 0
              : existing.unreadCount + 1,
      }
      const rest = state.chats.filter((c) => c.id !== msg.chatId)
      setChats([updated, ...rest])

      if (isActive) {
        socketRef.current?.emit('read', { chatId: msg.chatId })
      }
    },
    [addMessage, replaceTemp, setChats, loadChats]
  )

  // ---------------------------------------------------------------------
  // socket lifecycle
  // ---------------------------------------------------------------------
  useEffect(() => {
    let cancelled = false

    const setup = async () => {
      try {
        const res = await fetch('/api/auth/token')
        const data = await res.json()
        if (cancelled || !data.token) return
        const socket = getSocket(data.token)
        socketRef.current = socket

        socket.on('connect', () => setConnected(true))
        socket.on('disconnect', () => setConnected(false))
        socket.on('connect_error', () => setConnected(false))

        socket.on('presence-snapshot', (d: { onlineUserIds: string[] }) => {
          setOnlineIds(d.onlineUserIds)
        })
        socket.on('presence', (d: { userId: string; online: boolean }) => {
          setOnline(d.userId, d.online)
        })
        socket.on('new-message', (d: { message: ChatMessage; tempId: string | null }) => {
          applyNewMessage(d.message, d.tempId)
        })
        socket.on(
          'typing',
          (d: { chatId: string; userId: string; displayName: string; isTyping: boolean }) => {
            setTyping(d.chatId, d.userId, d.displayName, d.isTyping)
          }
        )
        socket.on(
          'chat-read',
          (d: { chatId: string; userId: string; lastReadAt: string }) => {
            setLastRead(d.chatId, d.userId, d.lastReadAt)
          }
        )
        socket.on('new-chat', (d: { chat: ChatSummary }) => {
          const exists = useChatStore.getState().chats.some((c) => c.id === d.chat.id)
          if (!exists) upsertChat(d.chat)
        })
        socket.on('user-updated', (d: { user: PublicUser }) => {
          const state = useChatStore.getState()
          if (d.user.id === state.me?.id) setMe(d.user)
          setUsers(state.users.map((u) => (u.id === d.user.id ? d.user : u)))
          setChats(
            state.chats.map((c) => ({
              ...c,
              members: c.members.map((m) => (m.id === d.user.id ? d.user : m)),
            }))
          )
        })
        socket.on('auth-error', () => {
          destroySocket()
          onLogout()
        })
      } catch {
        /* ignore */
      }
    }

    setup()

    return () => {
      cancelled = true
      socketRef.current?.removeAllListeners()
    }
     
  }, [])

  // ---------------------------------------------------------------------
  // prune stale typing indicators
  // ---------------------------------------------------------------------
  useEffect(() => {
    const interval = window.setInterval(() => {
      const state = useChatStore.getState()
      const now = Date.now()
      for (const [chatId, byUser] of Object.entries(state.typing)) {
        for (const [userId, info] of Object.entries(byUser)) {
          if (now - info.at > 4000) {
            state.setTyping(chatId, userId, info.displayName, false)
          }
        }
      }
    }, 1500)
    return () => window.clearInterval(interval)
  }, [])

  // ---------------------------------------------------------------------
  // open chat: load messages + mark read
  // ---------------------------------------------------------------------
  const openChat = useCallback(
    async (chatId: string) => {
      setActiveChatId(chatId)
      const state = useChatStore.getState()
      if (!state.messages[chatId]) {
        try {
          const res = await fetch(`/api/chats/${chatId}/messages`)
          if (res.ok) {
            const data = await res.json()
            setMessages(chatId, data.messages)
          }
        } catch {
          /* ignore */
        }
      }
      socketRef.current?.emit('read', { chatId })
      const chatsNow = useChatStore.getState().chats
      setChats(
        chatsNow.map((c) => (c.id === chatId ? { ...c, unreadCount: 0 } : c))
      )
    },
    [setActiveChatId, setMessages, setChats]
  )

  // ---------------------------------------------------------------------
  // actions
  // ---------------------------------------------------------------------
  const sendMessage = useCallback(
    (text: string, image: string | null) => {
      const chatId = activeChatIdRef.current
      if (!chatId || !me) return
      const tempId = `tmp-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
      const tempMsg: ChatMessage = {
        id: tempId,
        chatId,
        senderId: me.id,
        text: text || null,
        image,
        createdAt: new Date().toISOString(),
        sender: me,
        pending: true,
        tempId,
      }
      addMessage(tempMsg)

      // optimistic sidebar update
      const state = useChatStore.getState()
      const existing = state.chats.find((c) => c.id === chatId)
      if (existing) {
        const updated: ChatSummary = {
          ...existing,
          updatedAt: tempMsg.createdAt,
          lastMessage: {
            id: tempId,
            text: tempMsg.text,
            image: tempMsg.image,
            createdAt: tempMsg.createdAt,
            senderId: me.id,
            senderName: me.displayName,
          },
        }
        setChats([updated, ...state.chats.filter((c) => c.id !== chatId)])
      }

      socketRef.current?.emit(
        'send-message',
        { chatId, tempId, text: text || undefined, image: image || undefined },
        (res: { ok: boolean } | undefined) => {
          if (!res?.ok) {
            notify(t(lang, 'connectionLost'))
          }
        }
      )
    },
    [me, addMessage, setChats, notify, lang]
  )

  const sendTyping = useCallback((isTyping: boolean) => {
    const chatId = activeChatIdRef.current
    if (!chatId) return
    socketRef.current?.emit('typing', { chatId, isTyping })
  }, [])

  const startDm = useCallback(
    async (userId: string) => {
      try {
        const res = await fetch('/api/chats', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ type: 'dm', userId }),
        })
        if (!res.ok) return
        const data = await res.json()
        upsertChat(data.chat)
        socketRef.current?.emit('chat-created', { chatId: data.chat.id })
        await openChat(data.chat.id)
      } catch {
        /* ignore */
      }
    },
    [upsertChat, openChat]
  )

  const createGroup = useCallback(
    async (name: string, memberIds: string[]) => {
      try {
        const res = await fetch('/api/chats', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ type: 'group', name, memberIds }),
        })
        const data = await res.json()
        if (!res.ok) {
          notify(t(lang, 'loadFailed'))
          return
        }
        upsertChat(data.chat)
        socketRef.current?.emit('chat-created', { chatId: data.chat.id })
        await openChat(data.chat.id)
        notify(t(lang, 'groupCreatedBy'))
      } catch {
        notify(t(lang, 'connectionLost'))
      }
    },
    [upsertChat, openChat, notify, lang]
  )

  const handleLogout = useCallback(async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' })
    } catch {
      /* ignore */
    }
    destroySocket()
    socketRef.current = null
    onLogout()
  }, [onLogout])

  // ---------------------------------------------------------------------
  // derived
  // ---------------------------------------------------------------------
  const activeChat = useMemo(
    () => chats.find((c) => c.id === activeChatId) ?? null,
    [chats, activeChatId]
  )
  const activeMessages = activeChatId ? (messages[activeChatId] ?? []) : []

  const typingUsers = useMemo(() => {
    if (!activeChatId) return []
    return Object.values(typing[activeChatId] ?? {})
  }, [typing, activeChatId])

  const peerLastReadAt = useMemo(() => {
    if (!activeChat || activeChat.type !== 'dm' || !me) return undefined
    const peer = activeChat.members.find((m) => m.id !== me.id)
    if (!peer) return undefined
    return lastRead[activeChat.id]?.[peer.id] ?? activeChat.memberRead?.[peer.id]
  }, [activeChat, me, lastRead])

  // ---------------------------------------------------------------------
  return (
    <div className="relative flex h-dvh flex-col p-0 md:p-4">
      {!connected && (
        <div className="absolute top-3 left-1/2 z-40 flex -translate-x-1/2 items-center gap-2 rounded-full border border-rose-400/30 bg-rose-500/20 px-4 py-1.5 text-xs text-rose-100 backdrop-blur-xl">
          <WifiOff className="h-3.5 w-3.5" />
          {t(lang, 'connectionLost')}
        </div>
      )}

      <div className="mx-auto grid min-h-0 w-full max-w-7xl flex-1 md:grid-cols-[350px_1fr] md:gap-4">
        {/* sidebar */}
        <div
          className={cn(
            'min-h-0 md:flex md:flex-col',
            activeChat ? 'hidden' : 'flex flex-col'
          )}
        >
          <Sidebar
            me={me}
            chats={chats}
            users={users}
            activeChatId={activeChatId}
            onlineIds={onlineIds}
            typing={typing}
            onOpenChat={openChat}
            onStartDm={startDm}
            onNewChat={() => {
              loadUsers()
              setNewChatOpen(true)
            }}
            onNewGroup={() => {
              loadUsers()
              setNewGroupOpen(true)
            }}
            onProfile={() => setProfileOpen(true)}
            onLogout={handleLogout}
            onToggleLang={toggle}
          />
        </div>

        {/* chat window */}
        <div
          className={cn(
            'min-h-0 flex-1 md:flex md:flex-col',
            activeChat ? 'flex flex-col' : 'hidden'
          )}
        >
          {activeChat && me ? (
            <ChatWindow
              chat={activeChat}
              me={me}
              messages={activeMessages}
              onlineIds={onlineIds}
              typingUsers={typingUsers}
              peerLastReadAt={peerLastReadAt}
              onBack={() => setActiveChatId(null)}
              onSend={sendMessage}
              onTyping={sendTyping}
              onNotify={notify}
            />
          ) : (
            <div className="glass hidden h-full flex-col items-center justify-center gap-4 md:flex md:rounded-3xl">
              <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-violet-500/40 to-fuchsia-500/40 text-4xl">
                💬
              </div>
              <div className="text-lg font-semibold text-white/80">
                {t(lang, 'appName')} · {t(lang, 'welcome')} {me.displayName.split(' ')[0]}
              </div>
              <div className="text-sm text-white/40">{t(lang, 'noChatsHint')}</div>
            </div>
          )}
        </div>
      </div>

      {/* dialogs */}
      <ProfileDialog
        open={profileOpen}
        onOpenChange={setProfileOpen}
        me={me}
        onSaved={(user) => {
          setMe(user)
          const state = useChatStore.getState()
          setUsers(state.users.map((u) => (u.id === user.id ? user : u)))
          setChats(
            state.chats.map((c) => ({
              ...c,
              members: c.members.map((m) => (m.id === user.id ? user : m)),
            }))
          )
          socketRef.current?.emit('user-updated', { user })
        }}
        onNotify={notify}
      />
      <NewChatDialog
        open={newChatOpen}
        onOpenChange={setNewChatOpen}
        users={users}
        onStart={startDm}
      />
      <NewGroupDialog
        open={newGroupOpen}
        onOpenChange={setNewGroupOpen}
        users={users}
        onCreate={createGroup}
        onNotify={notify}
      />
    </div>
  )
}
