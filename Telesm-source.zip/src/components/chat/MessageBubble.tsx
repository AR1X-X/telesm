'use client'

import { Avatar } from './Avatar'
import { useLang, t, formatTime, formatDateLabel } from '@/lib/i18n'
import type { ChatMessage, ChatSummary, PublicUser } from '@/lib/types'
import { cn } from '@/lib/utils'
import { Check, CheckCheck } from 'lucide-react'

type MessageBubbleProps = {
  message: ChatMessage
  chat: ChatSummary
  me: PublicUser
  prev?: ChatMessage
  peerLastReadAt?: string
  onImageClick: (src: string) => void
}

export function MessageBubble({
  message,
  chat,
  me,
  prev,
  peerLastReadAt,
  onImageClick,
}: MessageBubbleProps) {
  const { lang } = useLang()
  const mine = message.senderId === me.id
  const isGroup = chat.type === 'group'
  const showAvatar = !mine && isGroup && (!prev || prev.senderId !== message.senderId)

  const prevDate = prev ? formatDateLabel(prev.createdAt, lang) : null
  const thisDate = formatDateLabel(message.createdAt, lang)
  const showDate = !prev || prevDate !== thisDate

  const seen =
    mine &&
    !!peerLastReadAt &&
    new Date(peerLastReadAt).getTime() >= new Date(message.createdAt).getTime()

  return (
    <>
      {showDate && (
        <div className="my-3 flex justify-center">
          <span className="glass rounded-full px-3 py-1 text-[11px] text-white/70">
            {thisDate}
          </span>
        </div>
      )}
      <div className={cn('flex w-full gap-2', mine ? 'justify-end' : 'justify-start')}>
        {!mine && (
          <div className="w-8 shrink-0 self-end">
            {showAvatar && (
              <Avatar
                id={message.sender.id}
                name={message.sender.displayName}
                src={message.sender.avatar}
                size={32}
              />
            )}
          </div>
        )}
        <div
          className={cn(
            'max-w-[78%] rounded-3xl px-3.5 py-2 shadow-md md:max-w-[65%]',
            mine
              ? 'bg-gradient-to-br from-violet-500 to-fuchsia-600 text-white'
              : 'glass border border-white/10 text-white'
          )}
        >
          {!mine && isGroup && showAvatar && (
            <div className="mb-0.5 text-xs font-bold text-fuchsia-300">
              {message.sender.displayName}
            </div>
          )}
          {message.image && (
             
            <img
              src={message.image}
              alt={`${t(lang, 'photoOf')} ${message.sender.displayName}`}
              onClick={() => onImageClick(message.image!)}
              className="mb-1 max-h-72 w-full cursor-zoom-in rounded-2xl object-cover"
            />
          )}
          {message.text && (
            <p className="whitespace-pre-wrap break-words text-[15px] leading-relaxed">
              {message.text}
            </p>
          )}
          <div
            className={cn(
              'mt-0.5 flex items-center justify-end gap-1 text-[10px]',
              mine ? 'text-white/75' : 'text-white/45'
            )}
          >
            {message.pending && <span>⏳</span>}
            {!message.pending && mine && seen && (
              <span className="flex items-center gap-0.5">
                {t(lang, 'seen')}
                <CheckCheck className="h-3.5 w-3.5" />
              </span>
            )}
            {!message.pending && mine && !seen && <Check className="h-3.5 w-3.5" />}
            <span dir="ltr">{formatTime(message.createdAt, lang)}</span>
          </div>
        </div>
      </div>
    </>
  )
}
