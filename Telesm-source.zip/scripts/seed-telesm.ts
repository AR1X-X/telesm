// Telesm seed: backfill phones for existing users + create the admin account.
// Idempotent — safe to run multiple times.  Run:  bun scripts/seed-telesm.ts
import { PrismaClient } from '@prisma/client'
import { randomBytes, scryptSync } from 'crypto'

const db = new PrismaClient()

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex')
  return `${salt}:${scryptSync(password, salt, 64).toString('hex')}`
}

async function upsertUser(opts: {
  username: string
  phone: string
  displayName: string
  password: string
  role: 'USER' | 'ADMIN'
}) {
  const existing = await db.user.findUnique({ where: { username: opts.username } })
  const data = {
    phone: opts.phone,
    passwordHint: opts.password,
    displayName: opts.displayName,
    role: opts.role,
  }
  if (existing) {
    await db.user.update({ where: { username: opts.username }, data })
    console.log(`updated  ${opts.username} (${opts.phone})`)
  } else {
    await db.user.create({
      data: { username: opts.username, password: hashPassword(opts.password), ...data },
    })
    console.log(`created  ${opts.username} (${opts.phone})`)
  }
}

async function main() {
  await upsertUser({ username: 'ali_teacher', phone: '09121111111', displayName: 'علی معلم', password: '1234', role: 'USER' })
  await upsertUser({ username: 'sara_student', phone: '09122222222', displayName: 'سارا دانش‌آموز', password: '1234', role: 'USER' })
  await upsertUser({ username: 'admin', phone: '09000000000', displayName: 'مدیر تلسِم', password: 'telesm_admin', role: 'ADMIN' })

  // any remaining users without a phone (created before Telesm) get a placeholder number
  const rest = await db.user.findMany({ where: { phone: null } })
  let i = 30
  for (const u of rest) {
    const phone = `091200000${i}${i}`
    i += 1
    await db.user.update({ where: { id: u.id }, data: { phone } })
    console.log(`backfill ${u.username} -> ${phone}`)
  }
  console.log('done ✔')
}

main().finally(() => db.$disconnect())
